/******************************************************************************
 -----------------------------------------------------------------------------
  Copyright (c) 2010-2011 QUALCOMM Incorporated.
  All Rights Reserved. QUALCOMM Proprietary and Confidential.
 -----------------------------------------------------------------------------
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#define MAX_LINE_LENGTH 80

#define MAX_RANDOM_NUMBERS 60

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(*(a)))

enum test_types {
    NOMINAL,
    ADVERSARIAL,
    REPEAT,
    RELEASE,
};

enum verbosity_level {
    PRINT_ERROR = 0,
    PRINT_WARNING,
    PRINT_INFO,
    PRINT_DEBUG,
};

typedef enum test_case {
    mode,
    temp,
    trip_point_0_type,
    trip_point_0_temp,
    trip_point_1_type,
    trip_point_1_temp,
} testcase;

typedef enum comparison_result {
    equal,
    greater,
    smaller,
} comparison;

static int verbosity;
static int iteration_number = 5;
static int interval_ms = 1000;
static int failure_number;
static char cmd[MAX_LINE_LENGTH];
static int numOfSensors = 1;
static char tsens_mode[MAX_LINE_LENGTH];
static char tsens_temp[MAX_LINE_LENGTH];
static char tsens_trip_0_type[MAX_LINE_LENGTH];
static char tsens_trip_0_temp[MAX_LINE_LENGTH];
static char tsens_trip_1_type[MAX_LINE_LENGTH];
static char tsens_trip_1_temp[MAX_LINE_LENGTH];

#define pr_err(msg, args...) do {                   \
            if (verbosity >= PRINT_ERROR)           \
                printf("\n"msg, ##args);\
        } while (0)

#define pr_warn(msg, args...) do {                  \
            if (verbosity >= PRINT_WARN)            \
                printf("\n"msg, ##args);\
        } while (0)

#define pr_info(msg, args...) do {                  \
            if (verbosity >= PRINT_INFO)            \
                printf("\n"msg, ##args);\
        } while (0)

#define pr_debug(msg, args...) do {                 \
            if (verbosity >= PRINT_DEBUG)           \
                printf("\n"msg, ##args);\
        } while (0)


static void setPath(int sensorNum)
{
    char sensor[10];
    sprintf(sensor, "%d", sensorNum);
    tsens_mode[0] = '\0';
    tsens_temp[0] = '\0';
    tsens_trip_0_type[0] = '\0';
    tsens_trip_0_temp[0] = '\0';
    tsens_trip_1_type[0] = '\0';
    tsens_trip_1_temp[0] = '\0';

    sprintf(tsens_mode, "/sys/class/thermal/thermal_zone");
    strcat(tsens_mode, sensor);
    strcat(tsens_mode, "/mode");

    sprintf(tsens_temp, "/sys/class/thermal/thermal_zone");
    strcat(tsens_temp, sensor);
    strcat(tsens_temp, "/temp");

    sprintf(tsens_trip_0_type, "/sys/class/thermal/thermal_zone");
    strcat(tsens_trip_0_type, sensor);
    strcat(tsens_trip_0_type, "/trip_point_0_type");

    sprintf(tsens_trip_0_temp, "/sys/class/thermal/thermal_zone");
    strcat(tsens_trip_0_temp, sensor);
    strcat(tsens_trip_0_temp, "/trip_point_0_temp");

    sprintf(tsens_trip_1_type, "/sys/class/thermal/thermal_zone");
    strcat(tsens_trip_1_type, sensor);
    strcat(tsens_trip_1_type, "/trip_point_1_type");

    sprintf(tsens_trip_1_temp, "/sys/class/thermal/thermal_zone");
    strcat(tsens_trip_1_temp, sensor);
    strcat(tsens_trip_1_temp, "/trip_point_1_temp");
}

static void showerrorandexit(char *message)
{
    printf("%s\n", message);
    failure_number++;
    if (verbosity < PRINT_DEBUG)
        exit(-1);
}

static int compare(char *name, char *expected, comparison cmp)
{
    FILE *fp;
    int count;
    char content[MAX_LINE_LENGTH];

    fp = fopen(name, "r");
    if (fp == NULL)
        return -1;
    memset(content, 0, MAX_LINE_LENGTH);
    count = fread(content, 1, 80, fp);
    fclose(fp);

    if (count == 0)
        return -1;

    content[count - 1] = 0; /* remove the return char */

    switch (cmp) {
    case equal:
        pr_debug("%s should be equal to %s\n", content, expected);
        if (strcmp(content, expected) == 0)
            return 0;
        break;
    case greater:
        pr_debug("%s should be greater than %s\n", content, expected);
        if (atoi(content) > atoi(expected))
            return 0;
        break;
    case smaller:
        pr_debug("%s should be smaller than %s\n", content, expected);
        if (atoi(content) < atoi(expected))
            return 0;
        break;
    default:
        showerrorandexit("This comparison condition does not exist!");
    }

    return -1;
}

static void check_read(testcase tc, char *expected, comparison cmp)
{
    switch (tc) {
    case mode:
        if (compare(tsens_mode, expected, cmp) < 0)
            showerrorandexit("Test failed: mode");
        break;
    case temp:
        if (compare(tsens_temp, expected, cmp) < 0)
            showerrorandexit("Test failed: temp");
        break;
    case trip_point_0_type:
        if (compare(tsens_trip_0_type, expected, cmp) < 0)
            showerrorandexit("Test failed: trip_point_0_type");
        break;
    case trip_point_0_temp:
        if (compare(tsens_trip_0_temp, expected, cmp) < 0)
            showerrorandexit("Test failed: trip_point_0_temp");
        break;
    case trip_point_1_type:
        if (compare(tsens_trip_1_type, expected, cmp) < 0)
            showerrorandexit("Test failed: trip_point_1_type");
        break;
    case trip_point_1_temp:
        if (compare(tsens_trip_1_temp, expected, cmp) < 0)
            showerrorandexit("Test failed: trip_point_1_temp");
        break;
    default:
        showerrorandexit("This test case does not exist!");
    }
}

static void set_value(testcase tc, char *value)
{
    sprintf(cmd, "echo -n \"");
    strcat(cmd, value);

    switch (tc) {
    case mode:
        strcat(cmd, "\" > ");
        strcat(cmd, tsens_mode);
        break;
    case trip_point_0_type:
        strcat(cmd, "\" > ");
        strcat(cmd, tsens_trip_0_type);
        break;
    case trip_point_0_temp:
        strcat(cmd, "\" > ");
        strcat(cmd, tsens_trip_0_temp);
        break;
    case trip_point_1_type:
        strcat(cmd, "\" > ");
        strcat(cmd, tsens_trip_1_type);
        break;
    case trip_point_1_temp:
        strcat(cmd, "\" > ");
        strcat(cmd, tsens_trip_1_temp);
        break;
    default:
        showerrorandexit("This test case does not exist!");
    }

    system(cmd);
}

static void nominal_test()
{
    int i, j;
    char iter[10];
    int highValue[MAX_RANDOM_NUMBERS];
    int lowValue[MAX_RANDOM_NUMBERS];

    srand(time(NULL));

     /* Generate random numbers */
     for (j = 0; j < MAX_RANDOM_NUMBERS; j++) {
        highValue[j] = 120 - (rand()%61);
        lowValue[j]= 40 - (rand()%61);
     }

    for (i=0; i < numOfSensors; i++) {
      setPath(i);
      pr_info("****** Start running nominal test with Sensor %d ******\n", i);

      pr_debug("set mode\n");
      set_value(mode, "enabled");
      check_read(mode, "enabled", equal);

      pr_debug("check trip point types\n");
      check_read(trip_point_0_type, "configurable_hi", equal);
      check_read(trip_point_1_type, "configurable_low", equal);
    
      pr_debug("activate trip points\n");
      set_value(trip_point_0_type, "enabled");
      set_value(trip_point_1_type, "enabled");

      /* test normal setting of trip point temp */
      pr_debug("test normal setting of trip point temp\n");
      set_value(trip_point_0_temp, "120");
      check_read(trip_point_0_temp, "120", equal);
      set_value(trip_point_1_temp, "90");
      check_read(trip_point_1_temp, "90", equal);

      /* test legal boundary setting of trip point temp */
      /* test lower boundary */
      pr_debug("test lower boundary setting of trip point temp\n");
      set_value(trip_point_0_temp, "90");
      check_read(trip_point_0_temp, "90", equal);
      set_value(trip_point_1_temp, "5");
      check_read(trip_point_1_temp, "5", equal);

      /* set values back */
      set_value(trip_point_0_temp, "120");
      check_read(trip_point_0_temp, "120", equal);
      set_value(trip_point_1_temp, "90");
      check_read(trip_point_1_temp, "90", equal);

      /* test upper boundary */
      pr_debug("test upper boundary setting of trip point temp\n");
      set_value(trip_point_1_temp, "120");
      check_read(trip_point_1_temp, "120", equal);

      pr_debug("test temp\n");
      check_read(temp, "100", smaller);
      check_read(temp, "-20", greater);

      /* set values back */
      set_value(trip_point_0_temp, "120");
      check_read(trip_point_0_temp, "120", equal);
      set_value(trip_point_1_temp, "90");
      check_read(trip_point_1_temp, "90", equal);

      /* test zero and negative values */
      set_value(trip_point_1_temp, "-40");
      check_read(trip_point_1_temp, "-40", equal);
      set_value(trip_point_0_temp, "-30");
      check_read(trip_point_0_temp, "-30", equal);

      set_value(trip_point_0_temp, "0");
      check_read(trip_point_0_temp, "0", equal);
      set_value(trip_point_0_temp, "0");
      check_read(trip_point_0_temp, "0", equal);

      /* test each trip point with wide temperature range */
      pr_debug("test each trip point with wide temperature range\n");
      set_value(trip_point_1_temp, "-30");
      check_read(trip_point_1_temp, "-30", equal);
      
      for (j=-30; j <= 140; j++) {
        iter[0] = '\0';
        sprintf(iter, "%d", j);
        set_value(trip_point_0_temp, iter);
        check_read(trip_point_0_temp, iter, equal);

        set_value(trip_point_1_temp, iter);
        check_read(trip_point_1_temp, iter, equal);
      }

      set_value(trip_point_1_temp, "-30");
      check_read(trip_point_1_temp, "-30", equal);

      for (j=0; j < MAX_RANDOM_NUMBERS; j++) {
        iter[0] = '\0';
        sprintf(iter, "%d", highValue[j]);
        set_value(trip_point_0_temp, iter);
        check_read(trip_point_0_temp, iter, equal);

        iter[0] = '\0';
        sprintf(iter, "%d", lowValue[j]);
        set_value(trip_point_1_temp, iter);
        check_read(trip_point_1_temp, iter, equal);
      }
     
      if (verbosity < PRINT_DEBUG){
         pr_info("Nominal test passed with Sensor %d \n", i);
      }
   }
}

static void adversarial_test()
{
    int i, j;
    char iter[10];
    int highValue[MAX_RANDOM_NUMBERS];
    int lowValue[MAX_RANDOM_NUMBERS];

    /* Generate random numbers */
    for (j = 0; j < MAX_RANDOM_NUMBERS; j++) {
       srand(time(0));
       highValue[j] = 120 - (rand()%61);
       lowValue[j]= 40 - (rand()%61);
    }

    for (i=0; i <numOfSensors; i++) {
      setPath(i);
      pr_info("****** Start running adversarial test ******\n");

      set_value(mode, "enabled");
      set_value(trip_point_0_type, "enabled");
      set_value(trip_point_1_type, "enabled");

      set_value(trip_point_0_temp, "120");
      set_value(trip_point_1_temp, "90");
   
      pr_debug("test illegal setting of trip point temp\n");
      set_value(trip_point_0_temp, "89");
      check_read(trip_point_0_temp, "120", equal);
      set_value(trip_point_1_temp, "121");
      check_read(trip_point_1_temp, "90", equal);

      set_value(trip_point_0_temp, "240");
      check_read(trip_point_0_temp, "194", smaller);
      set_value(trip_point_1_temp, "-20");
      check_read(trip_point_1_temp, "-60", greater);

      /* set to the original value */
      set_value(trip_point_1_temp, "90");
      set_value(trip_point_0_temp, "120");
      
      for (j=0; j < MAX_RANDOM_NUMBERS; j++) {
        iter[0] = '\0';
        sprintf(iter, "%d", lowValue[j]);
        set_value(trip_point_0_temp, iter);
        check_read(trip_point_0_temp, "120", equal);
      }
      set_value(trip_point_1_temp, "-20");
      set_value(trip_point_0_temp, "59");

      for (j=0; j < MAX_RANDOM_NUMBERS; j++) {
        iter[0] = '\0';
        sprintf(iter, "%d", highValue[j]);
        set_value(trip_point_1_temp, iter);
        check_read(trip_point_1_temp, "-20", equal);
      }
    }

    if (verbosity < PRINT_DEBUG)
      pr_info("Adversarial test passed\n");
}

static void repeatability_test()
{
    int i;

    pr_info("Start running repeatability test\n");
    for (i = 1; i <= iteration_number; i++) {
        pr_info("Iteration %d of repeatability test\n", i);
        nominal_test();
        adversarial_test();
        usleep(interval_ms*1000);
    }

    if (verbosity < PRINT_DEBUG)
        pr_info("Repeatability test passed\n");
}

static void release_test()
{
    pr_info("Start running release test\n");

    nominal_test();
    adversarial_test();
    repeatability_test();

    if (verbosity < PRINT_DEBUG)
        pr_info("Release test passed\n");
}



static int (*test_func[]) () = {
    [NOMINAL] = nominal_test,
    [ADVERSARIAL] = adversarial_test,
    [REPEAT] = repeatability_test,
    [RELEASE] = release_test,
};

static void usage(int ret)
{
    printf("Usage: msm_tsens_test [OPTIONS] [TEST_TYPE]...\n"
        "Runs the user space tests specified by the TEST_TYPE\n"
        "parameters.  If no TEST_TYPE is specified, then the release\n"
        " test is run.\n"
        "\n"
        "OPTIONS can be:\n"
        "  -v, --verbose         run with debug messages on\n"
        "                           (debugging level: 0-3).\n"
        "  -i, --iteration       iteration number for repeatability\n"
        "  -t, --interval        interval (ms) between two iterations\n"
        "\n"
        "TEST_TYPE can be:\n"
        "  -n, --nominal         run standard functionality tests\n"
        "  -a, --adversarial     run tests that try to break the \n"
        "                          driver\n"
        "  -p, --repeatability   run 5 iterations of both the \n"
        "                          nominal and adversarial tests\n"
        "  -r, --release         run one iteration of the nominal, \n"
        "                        adversarial and repeatability tests\n"
        "  -h, --help            print this help message and exit\n");

    exit(ret);
}

static uint32_t parse_command(int argc, char *const argv[])
{
    int command;
    unsigned ret = 0;

    struct option longopts[] = {
        {"verbose", required_argument, NULL, 'v'},
        {"iteration", required_argument, NULL, 'i'},
        {"interval", required_argument, NULL, 't'},
        {"nominal", no_argument, NULL, 'n'},
        {"adversarial", no_argument, NULL, 'a'},
        {"repeatability", no_argument, NULL, 'p'},
        {"release", no_argument, NULL, 'r'},
        {"sensors", required_argument, NULL, 's'},
        {"help", no_argument, NULL, 'h'},
        {NULL, 0, NULL, 0},
    };

    while ((command = getopt_long(argc, argv, "v:i:t:naprs:h", longopts,
                      NULL)) != -1) {
        switch (command) {
        case 'v':
            verbosity = (int)(strtol(optarg, NULL, 0));
            break;
        case 'i':
            iteration_number = (int)(strtol(optarg, NULL, 0));
            break;
        case 't':
            interval_ms = (int)(strtol(optarg, NULL, 0));
            break;
        case 'n':
            ret |= 1 << NOMINAL;
            break;
        case 'a':
            ret |= 1 << ADVERSARIAL;
            break;
        case 'p':
            ret |= 1 << REPEAT;
            break;
        case 'r':
            ret |= 1 << RELEASE;
            break;
        case 's':
            numOfSensors = (int)(strtol(optarg, NULL, 0));
            break;
        case 'h':
            usage(0);
        default:
            usage(-1);
        }
    }

    return ret;
}

int main(int argc, char **argv)
{
    int rc = 0, num_tests_failed = 0, i;
    uint32_t test_mask = parse_command(argc, argv);

    /* Run the release case if none is specified */
    if (test_mask == 0)
        test_mask = 1 << RELEASE;


    for (i = 0; i < (int)ARRAY_SIZE(test_func); i++) {
        /* Look for the test that was selected */
        if (!(test_mask & (1U << i)))
            continue;

        /* This test was selected, so run it */
        test_func[i] ();
    }

    if (failure_number == 0)
        printf("All tests have been passed.\n");
    else
        printf("%d test case(s) failed.\n", failure_number);

    return 0;
}
