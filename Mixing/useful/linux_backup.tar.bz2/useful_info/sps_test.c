/* Copyright (c) 2011-2012, Code Aurora Forum. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */

/**
 * SPS driver Unit-Test using BAM-DMA hardware.
 */



#include <linux/types.h>	/* u32 */
#include <linux/kernel.h>	/* pr_info() */
#include <linux/slab.h>		/* kzalloc() */
#include <linux/mutex.h>	/* mutex */
#include <linux/list.h>		/* list_head */
#include <linux/delay.h>	/* msleep */
#include <linux/memory.h>	/* memset */
#include <linux/device.h>	/* device */
#include <linux/cdev.h>		/* cdev_alloc() */
#include <linux/fs.h>		/* alloc_chrdev_region() */
#include <linux/module.h>	/* module_init() */
#include <linux/dma-mapping.h>	/* dma_alloc_coherent() */
#include <linux/io.h>
#include <asm/uaccess.h>
#include <linux/msm-sps.h>		/* SPS API*/

void * bamdma_virt_addr;

/** Module name string */
#define DRV_MAME "sps_test"
#define DRV_VERSION "2.0"

//need to comment these three lines when do testing for A family
#ifndef CONFIG_SPS_SUPPORT_NDP_BAM
#define CONFIG_SPS_SUPPORT_NDP_BAM
#endif

#ifdef CONFIG_SPS_SUPPORT_NDP_BAM
#define BAM_PHYS_ADDR 0xF9984000
#define BAM_PHYS_SIZE 0x15000
#define DMA_PHYS_ADDR 0xF9999000
#define DMA_PHYS_SIZE 0xB000
#else
#define BAM_PHYS_ADDR 0x12244000
#define BAM_PHYS_SIZE 0x4000
#define DMA_PHYS_ADDR 0x12240000
#define DMA_PHYS_SIZE 0x1000
#endif

#define TEST_SIGNATURE 0xfacecafe

#define BAMDMA_MAX_CHANS 10

#define DFAB_ARB1_HCLK_CTL		(MSM_CLK_CTL_BASE + 0x2564)

struct test_context {
	dev_t dev_num;
	struct device *dev;
	struct cdev *cdev;

	long testcase;

	void *bam;
	int is_bam_registered;

	void *dma;

	u32 signature;
};

struct test_endpoint {
	struct sps_pipe *sps;
	struct sps_connect connect;
	struct sps_register_event reg_event;
	int is_bam2bam;

	struct sps_iovec IOVec;

	struct completion xfer_done;

	u32 signature;
};

static struct test_context *sps_test;
static u32 sps_test_num;



/**
 * Allocate memory from pipe-memory or system memory.
 *
 * @param use_pipe_mem
 * @param mem
 */
static void test_alloc_mem(int use_pipe_mem, struct sps_mem_buffer *mem)
{
	//struct sps_pipe dummy;
	//struct sps_pipe *h = sps_alloc_endpoint();
	//dummy.pipe_index = 0;

	if (use_pipe_mem) {
		sps_alloc_mem(NULL, SPS_MEM_LOCAL, mem);
	} else {
		//dma_addr_t dma_addr;

		mem->base = dma_alloc_coherent(sps_test->dev, mem->size, &mem->phys_base, GFP_KERNEL);
		//mem->phys_base = dma_addr;
	}


}

/**
 * Free memory from pipe-memory or system memory.
 *
 * @param use_pipe_mem
 * @param mem
 */
static void test_free_mem(int use_pipe_mem, struct sps_mem_buffer *mem)
{
	if (use_pipe_mem) {
		sps_free_mem(NULL, mem);
	} else {
		dma_addr_t dma_addr = mem->phys_base;

		if (dma_addr)
			dma_free_coherent(sps_test->dev, mem->size, mem->base, dma_addr);

		mem->phys_base = 0;
		mem->base = NULL;
	}
}

/* output the content of BAM-level registers */
static void print_bam_reg(void *virt_addr)
{
	int i, n;
	u32 *bam = (u32 *) virt_addr;
	u32 ctrl;
	u32 ver;
	u32 pipes;

	if (bam == NULL)
		return;

#ifdef CONFIG_SPS_SUPPORT_NDP_BAM
	ctrl = bam[0x0 / 4];
	ver = bam[0x4 / 4];
	pipes = bam[0x3c / 4];
#else
	ctrl = bam[0xf80 / 4];
	ver = bam[0xf84 / 4];
	pipes = bam[0xfbc / 4];
#endif

	pr_info("\nsps:----- Content of BAM-level registers <begin> -----\n");

	pr_info("BAM_CTRL: 0x%x.\n", ctrl);
	pr_info("BAM_REVISION: 0x%x.\n", ver);
	pr_info("NUM_PIPES: 0x%x.\n", pipes);

#ifdef CONFIG_SPS_SUPPORT_NDP_BAM
	for (i = 0x0; i < 0x80; i += 0x10)
#else
	for (i = 0xf80; i < 0x1000; i += 0x10)
#endif
		pr_info("bam addr 0x%x: 0x%x,0x%x,0x%x,0x%x.\n", i,
			bam[i / 4], bam[(i / 4) + 1],
			bam[(i / 4) + 2], bam[(i / 4) + 3]);

#ifdef CONFIG_SPS_SUPPORT_NDP_BAM
	for (i = 0x800, n = 0; n++ < 8; i += 0x80)
#else
	for (i = 0x1800, n = 0; n++ < 4; i += 0x80)
#endif
		pr_info("bam addr 0x%x: 0x%x,0x%x,0x%x,0x%x.\n", i,
			bam[i / 4], bam[(i / 4) + 1],
			bam[(i / 4) + 2], bam[(i / 4) + 3]);

	pr_info("\nsps:----- Content of BAM-level registers <end> -----\n");
}

/* output the content of BAM pipe registers */
static void print_bam_pipe_reg(void *virt_addr, u32 pipe_index)
{
	int i;
	u32 *bam = (u32 *) virt_addr;
	u32 pipe = pipe_index;

	if (bam == NULL)
		return;

	pr_info("\nsps:----- Content of Pipe %d registers <begin> -----\n",
			pipe);

	pr_info("-- Pipe Management Registers --\n");

#ifdef CONFIG_SPS_SUPPORT_NDP_BAM
	for (i = 0x1000 + 0x1000 * pipe; i < 0x1000 + 0x1000 * pipe + 0x80;
	    i += 0x10)
#else
	for (i = 0x0000 + 0x80 * pipe; i < 0x0000 + 0x80 * (pipe + 1);
	    i += 0x10)
#endif
		pr_info("bam addr 0x%x: 0x%x,0x%x,0x%x,0x%x.\n", i,
			bam[i / 4], bam[(i / 4) + 1],
			bam[(i / 4) + 2], bam[(i / 4) + 3]);

	pr_info("-- Pipe Configuration and Internal State Registers --\n");

#ifdef CONFIG_SPS_SUPPORT_NDP_BAM
	for (i = 0x1800 + 0x1000 * pipe; i < 0x1800 + 0x1000 * pipe + 0x40;
	    i += 0x10)
#else
	for (i = 0x1000 + 0x40 * pipe; i < 0x1000 + 0x40 * (pipe + 1);
	    i += 0x10)
#endif
		pr_info("bam addr 0x%x: 0x%x,0x%x,0x%x,0x%x.\n", i,
			bam[i / 4], bam[(i / 4) + 1],
			bam[(i / 4) + 2], bam[(i / 4) + 3]);

	pr_info("\nsps:----- Content of Pipe %d registers <end> -----\n",
			pipe);
}


/*
 * print both BAM register info and desc FIFO info
 * second pair of pipes is optional
 * assign tx2_pipe with a value bigger than 31 to skip the second pair
 */
static void print_BAM_reg_and_desc_FIFO(u32 *bam,
		u32 tx_pipe, u32 rx_pipe, u32 tx2_pipe, u32 rx2_pipe,
		struct sps_mem_buffer tx_desc_fifo,
		struct sps_mem_buffer rx_desc_fifo,
		struct sps_mem_buffer tx2_desc_fifo,
		struct sps_mem_buffer rx2_desc_fifo)
{
	u32 *desc = NULL;

	/* output register info */
	print_bam_reg(bam);
	print_bam_pipe_reg(bam, tx_pipe);
	print_bam_pipe_reg(bam, rx_pipe);

	if (tx2_pipe < 32) {
		print_bam_pipe_reg(bam, tx2_pipe);
		print_bam_pipe_reg(bam, rx2_pipe);
	}

	/* output desc FIFO content */
	desc = tx_desc_fifo.base;
	pr_info("tx desc-fifo at %pa:\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n"
			"0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n",
		&tx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
		desc[3], desc[4], desc[5], desc[6], desc[7], desc[8], desc[9],
		desc[10], desc[11], desc[12], desc[13], desc[14],
		desc[15], desc[16], desc[17], desc[18], desc[19]);
	desc = rx_desc_fifo.base;
	pr_info("rx desc-fifo at %pa:\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n"
			"0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n",
		&rx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
		desc[3], desc[4], desc[5], desc[6], desc[7], desc[8], desc[9],
		desc[10], desc[11], desc[12], desc[13], desc[14],
		desc[15], desc[16], desc[17], desc[18], desc[19]);

	if (tx2_pipe < 32) {
		desc = tx2_desc_fifo.base;
		pr_info("tx2 desc-fifo at %pa:\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n"
			"0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n",
			&tx2_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3], desc[4], desc[5], desc[6], desc[7], desc[8], desc[9],
			desc[10], desc[11], desc[12], desc[13], desc[14],
			desc[15], desc[16], desc[17], desc[18], desc[19]);
		desc = rx2_desc_fifo.base;
		pr_info("rx2 desc-fifo at %pa:\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n"
			"0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n0x%x,0x%x,0x%x,0x%x\n",
			&rx2_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3], desc[4], desc[5], desc[6], desc[7], desc[8], desc[9],
			desc[10], desc[11], desc[12], desc[13], desc[14],
			desc[15], desc[16], desc[17], desc[18], desc[19]);
	}
}


/**
 * register_bam
 *
 * @bam
 * @use_irq
 *
 * @return void*
 */
static void *register_bam(unsigned long *h, int use_irq)
{
	int res = 0;
	struct sps_bam_props bam_props = { 0};
	unsigned long bam_handle;

	bam_props.phys_addr = BAM_PHYS_ADDR;
	bam_props.virt_addr = ioremap(BAM_PHYS_ADDR, BAM_PHYS_SIZE);
	bam_props.event_threshold = 0x10;	/* Pipe event threshold */
	bam_props.summing_threshold = 0x10;	/* BAM event threshold */

	pr_info(DRV_MAME ":bam physical base=%pa\n",
			&bam_props.phys_addr);
	pr_info(DRV_MAME ":bam virtual base=0x%p\n",
			bam_props.virt_addr);

	if (use_irq)
		bam_props.irq = 126; //SPS_BAM_DMA_IRQ;
	else
		bam_props.irq = 0;

#ifdef CONFIG_SPS_SUPPORT_BAMDMA
	/* fall back if BAM-DMA already registered */
	pr_info(DRV_MAME ":use sps_dma_get_bam_handle().\n");
	bam_handle = sps_dma_get_bam_handle();
	if (bam_handle == 0)
		return NULL;
	*h = bam_handle;

	sps_test->bam = bam_props.virt_addr;

	return sps_test->bam;
#endif

	res = sps_register_bam_device(&bam_props, &bam_handle);

	if (res == 0) {
		*h = bam_handle;
		sps_test->is_bam_registered = true;
	} else
		return NULL;

	sps_test->bam = bam_props.virt_addr;

	return sps_test->bam;
}

static void deregister_bam(void *bam, u32 h)
{
	if (bam != NULL)
		iounmap(bam);

	if (sps_test->is_bam_registered) {
		sps_deregister_bam_device(h);
		sps_test->is_bam_registered = false;
	}

	sps_test->bam = NULL;
}

static void rx_event_callback_notify(struct sps_event_notify *notify)
{
	pr_info("%s: Event %d notified\n", __func__, notify->event_id);
	if (notify->event_id == SPS_EVENT_HRESP_ERROR)
		pr_info("SPS_EVENT_HRESP_ERROR\n");
}


static void tx_event_callback_notify(struct sps_event_notify *notify)
{
	pr_info("%s: Event %d notified\n", __func__, notify->event_id);
	if (notify->event_id == SPS_EVENT_HRESP_ERROR)
		pr_info("SPS_EVENT_HRESP_ERROR\n");
}

static int wait_xfer_completion(int use_irq,
				struct completion *xfer_done,
				struct sps_pipe *sps,
				int rx_xfers,
				u32 max_retry,
				u32 delay_ms)
{
	struct sps_event_notify dummy_event = {0};
	int i;

	if (use_irq) {
		unsigned long timeout;
		timeout = 300 * msecs_to_jiffies(1);
		if (!wait_for_completion_timeout(xfer_done, timeout))
			return -1;
	} else {
		for (i = 0; i < rx_xfers; i++) {
			u32 retry = 0;
			while (!try_wait_for_completion(xfer_done)) {
				//sps_get_event() is polling the pipe and trigger the event
				sps_get_event(sps, &dummy_event);

				if (retry++ >= max_retry)
					return -EBUSY;

				if (delay_ms)
					msleep(delay_ms);
			}	/* end-of-while */
		}	/* end-of-for */
	}	/* end-of-if */

	return 0;
}

/* single transfer for BAM-to-System mode */
static int sps_test_sys2bam(int use_irq,
			    int use_pipe_mem,
			    int use_cache_mem_data_buf,
			    int loop_test)
{
	int res = 0;

	struct test_endpoint test_ep[2];
	struct test_endpoint *tx_ep = &test_ep[0];
	struct test_endpoint *rx_ep = &test_ep[1];

	void *bam = NULL;
	unsigned long h = 0;
	struct sps_connect tx_connect = { 0};
	struct sps_connect rx_connect = { 0};

	struct sps_mem_buffer tx_desc_fifo = { 0};
	struct sps_mem_buffer rx_desc_fifo = { 0};

	struct sps_mem_buffer tx_mem = { 0};
	struct sps_mem_buffer rx_mem = { 0};

	struct sps_pipe *tx_h_sps = NULL;
	struct sps_pipe *rx_h_sps = NULL;

	struct sps_iovec tx_iovec = { 0};
	struct sps_iovec rx_iovec = { 0};
	unsigned long *desc = NULL;
	unsigned long *tx_buf = NULL;
	unsigned long *rx_buf = NULL;

	u32 tx_pipe = 4;
	u32 rx_pipe = 5;

	u32 tx_xfer_flags = 0;
	u32 rx_xfer_flags = 0;

	struct sps_register_event tx_event = { 0};
	struct sps_register_event rx_event = { 0};

	u32 tx_size = 0x400;
	u32 rx_size = 0x800;	/* This the max size and not the actual size */

	u32 tx_connect_options = 0;
	u32 rx_connect_options = 0;
	char *irq_mode = use_irq ? "IRQ mode" : "Polling mode";
	char *mem_type = use_pipe_mem ? "Pipe-Mem" : "Sys-Mem";
	int loop = 0;
	int max_loops = 1;

	memset(test_ep, 0, sizeof(test_ep));
	tx_ep->signature = TEST_SIGNATURE;
	rx_ep->signature = TEST_SIGNATURE;

	pr_info(DRV_MAME ":----Register BAM ----\n");

	bam = register_bam(&h, use_irq);
	if (bam == NULL) {
		res = -1;
		goto register_err;
	}

	tx_ep->sps = sps_alloc_endpoint();
	rx_ep->sps = sps_alloc_endpoint();
	tx_h_sps = tx_ep->sps;
	rx_h_sps = rx_ep->sps;

	res = sps_get_config(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;
	res = sps_get_config(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect TX = MEM->BAM = Consumer ----\n");
	tx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		tx_connect_options |= SPS_O_POLL;

	tx_connect.source = SPS_DEV_HANDLE_MEM;	/* Memory */
	tx_connect.destination = h;
	tx_connect.mode = SPS_MODE_DEST;	/* Consumer pipe */
	//tx_connect.src_pipe_index = rx_pipe;
	tx_connect.dest_pipe_index = tx_pipe;
	tx_connect.event_thresh = 0x10;
	tx_connect.options = tx_connect_options;

	//tx_desc_fifo.size = 0x100;
	tx_desc_fifo.size = 0x40; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &tx_desc_fifo);
	memset(tx_desc_fifo.base, 0x00, tx_desc_fifo.size);
	tx_connect.desc = tx_desc_fifo;

	res = sps_connect(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect RX = BAM->MEM = Producer----\n");
	rx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		rx_connect_options |= SPS_O_POLL;

	rx_connect.source = h;
	rx_connect.destination = SPS_DEV_HANDLE_MEM;	/* Memory */
	rx_connect.mode = SPS_MODE_SRC;	/* Producer pipe */
	rx_connect.src_pipe_index = rx_pipe;
	//rx_connect.dest_pipe_index = tx_pipe;
	rx_connect.event_thresh = 0x10;
	rx_connect.options = rx_connect_options;

	/* rx_desc_fifo.size = 0x100; */
	rx_desc_fifo.size = 0x40; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &rx_desc_fifo);
	memset(rx_desc_fifo.base, 0x00, rx_desc_fifo.size);
	rx_connect.desc = rx_desc_fifo;

	res = sps_connect(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":-----Allocate Buffers----\n");
	tx_mem.size = tx_size;
	rx_mem.size = rx_size;

	pr_info(DRV_MAME ":Allocating Data Buffers from %s.\n", mem_type);
	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;


		mem = &tx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */

		mem = &rx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */
	} else {
		test_alloc_mem(use_pipe_mem, &tx_mem);
		test_alloc_mem(use_pipe_mem, &rx_mem);
	}

	pr_info(DRV_MAME ":%s.tx mem phys=%pa.virt=0x%p.\n",
		__func__, &tx_mem.phys_base, tx_mem.base);
	pr_info(DRV_MAME ":%s.rx mem phys=%pa.virt=0x%p.\n",
		__func__, &rx_mem.phys_base, rx_mem.base);

	tx_buf = tx_mem.base;
	rx_buf = rx_mem.base;

	tx_event.mode = SPS_TRIGGER_CALLBACK;
	tx_event.options = SPS_O_EOT;
	tx_event.user = (void *)tx_ep;
	init_completion(&tx_ep->xfer_done);
	tx_event.xfer_done = &tx_ep->xfer_done;
	pr_info(DRV_MAME ":tx_event.event=0x%p.\n", tx_event.xfer_done);

	rx_event.mode = SPS_TRIGGER_CALLBACK;
	rx_event.options = SPS_O_EOT;
	rx_event.user = (void *)rx_ep;
	init_completion(&rx_ep->xfer_done);
	rx_event.xfer_done = &rx_ep->xfer_done;
	pr_info(DRV_MAME ":rx_event.event=0x%p.\n", rx_event.xfer_done);

	/* WARNING: MUST register reg_event to enable interrupt
	   on the pipe level. */
	res = sps_register_event(tx_h_sps, &tx_event);
	if (res)
		goto exit_err;
	res = sps_register_event(rx_h_sps, &rx_event);
	if (res)
		goto exit_err;

	if (loop_test) {
		max_loops = tx_size / 0x40;
		pr_info(DRV_MAME ":----- Start testing for %d loops ----\n", max_loops);
	}

	for (loop = 0; loop < max_loops; loop++) {
		init_completion(&tx_ep->xfer_done);
		init_completion(&rx_ep->xfer_done);

		pr_info(DRV_MAME ":-----Prepare Buffers----\n");

		memset(tx_buf, 0xaa, tx_mem.size);
		memset(rx_buf, 0xbb, rx_mem.size);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
			mem = &rx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
		}

		pr_info(DRV_MAME ":-----Start Transfers----\n");

		rx_xfer_flags = 0;
		res = sps_transfer_one(rx_h_sps, rx_mem.phys_base, rx_size,
				       rx_h_sps, rx_xfer_flags);
		pr_info("sps_transfer_one rx res = %d.\n", res);
		if (res)
			goto exit_err;

		tx_xfer_flags =	SPS_IOVEC_FLAG_EOT;
		res = sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, tx_xfer_flags);

		pr_info("sps_transfer_one tx res = %d.\n", res);
		if (res)
			goto exit_err;


		pr_info(DRV_MAME ":-----Wait Transfers Complete----\n");

		msleep(10); /* allow transfer to complete */

		/* output register info */
		print_bam_reg(bam);
		print_bam_pipe_reg(bam, tx_pipe);
		print_bam_pipe_reg(bam, rx_pipe);

		/* output desc FIFO content */
		desc = tx_desc_fifo.base;
		pr_info("tx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&tx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);
		desc = rx_desc_fifo.base;
		pr_info("rx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&rx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);

		/* wait for interrupt or check if the transfer is complete on RX pipe */
		res = wait_xfer_completion(use_irq, &rx_ep->xfer_done,
					   rx_h_sps, 1, 3, 0);

		if (res) {
			pr_err("sps_test:%s.transfer is not completed.\n",
			       __func__);
			goto exit_err;
		}

		sps_get_iovec(tx_ep->sps, &tx_ep->IOVec);
		sps_get_iovec(rx_ep->sps, &rx_ep->IOVec);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
			mem = &rx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
		}

		tx_iovec = tx_ep->IOVec;
		rx_iovec = rx_ep->IOVec;

		pr_info(DRV_MAME ":-----Check Pass/Fail----\n");

		pr_info("sps_get_iovec tx size = %d.\n", tx_iovec.size);
		pr_info("sps_get_iovec rx size = %d.\n", rx_iovec.size);

		pr_info("tx buf[0] = 0x%lx.\n", tx_buf[0]);
		pr_info("rx buf[0] = 0x%lx.\n", rx_buf[0]);
		pr_info("tx buf[tx_size/8-1] = 0x%lx.\n",
			tx_buf[tx_size / 8 - 1]);
		pr_info("rx buf[tx_size/8-1] = 0x%lx.\n",
			rx_buf[tx_size / 8 - 1]);

		/* NOTE: Rx according to Tx size with EOT. */
		if ((tx_iovec.size == tx_size) &&
		    (rx_iovec.size == tx_size) &&
		    (tx_buf[0] == rx_buf[0]) &&
		    (tx_buf[tx_size / 8 - 1] == rx_buf[tx_size / 8 - 1])
		   ) {
			res = 0;
			if (loop_test)
				pr_info("sps:No. %d loop PASS.\n", loop + 1);
		} else {
			res = -1;
			break;
		}

		if (loop_test)
			tx_size -= 0x40;
	}

exit_err:

	pr_info(DRV_MAME ":-----Tear Down----\n");

	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		kfree(mem->base);
		mem = &rx_mem;
		kfree(mem->base);
	} else {
		test_free_mem(use_pipe_mem, &tx_mem);
		test_free_mem(use_pipe_mem, &rx_mem);
	}
	test_free_mem(use_pipe_mem, &tx_desc_fifo);
	test_free_mem(use_pipe_mem, &rx_desc_fifo);

	sps_disconnect(tx_h_sps);
	sps_disconnect(rx_h_sps);

	deregister_bam(bam, h);

register_err:
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
	if (res == 0)
		pr_info("SPS #%d BAM-DMA SYS-BAM Test %s DESC %s - PASS.\n",
			sps_test_num, irq_mode, mem_type);
	else
		pr_info("SPS #%d BAM-DMA SYS-BAM Test %s DESC %s - FAIL.\n",
			sps_test_num, irq_mode, mem_type);
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	return res;
}	/* single transfer for BAM-to-System mode */


/* MULTIPLE DESCRIPTORS PER TRANSFER or MULTIPLE TRANSFERS */
static int sps_test_multi(int use_irq,
	int use_pipe_mem,int tx_eot_per_xfer)
{
	int res = 0;
	int use_cache_mem_data_buf = false;
	int loop_test = false;

	struct test_endpoint test_ep[2];
	struct test_endpoint *tx_ep = &test_ep[0];
	struct test_endpoint *rx_ep = &test_ep[1];

	void *bam = NULL;
	unsigned long h = 0;
	struct sps_connect tx_connect = { 0};
	struct sps_connect rx_connect = { 0};

	struct sps_mem_buffer tx_desc_fifo = { 0};
	struct sps_mem_buffer rx_desc_fifo = { 0};

	struct sps_mem_buffer tx_mem = { 0};
	struct sps_mem_buffer rx_mem = { 0};

	struct sps_pipe *tx_h_sps = NULL;
	struct sps_pipe *rx_h_sps = NULL;

	struct sps_iovec tx_iovec = { 0};
	struct sps_iovec rx_iovec = { 0};
	unsigned long *desc = NULL;
	unsigned long *tx_buf = NULL;
	unsigned long *rx_buf = NULL;

	u32 tx_pipe = 4;
	u32 rx_pipe = 5;

	u32 tx_xfer_flags = 0;
	u32 rx_xfer_flags = 0;

	struct sps_register_event tx_event = { 0};
	struct sps_register_event rx_event = { 0};

	u32 tx_size = 0x400;
	u32 rx_size = 0x800;	/* This the max size and not the actual size */

	u32 tx_connect_options = 0;
	u32 rx_connect_options = 0;
	char *irq_mode = use_irq ? "IRQ mode" : "Polling mode";
	char *mem_type = use_pipe_mem ? "Pipe-Mem" : "Sys-Mem";
	int loop = 0;
	int max_loops = 1;
	int tx_multi = 1;
	int rx_multi = 1;
	u32 total_tx_size = 0;
	u32 total_rx_size = 0;
	int i;

	memset(test_ep, 0, sizeof(test_ep));
	tx_ep->signature = TEST_SIGNATURE;
	rx_ep->signature = TEST_SIGNATURE;

	pr_info(DRV_MAME ":----Register BAM ----\n");
	bam = register_bam(&h, use_irq);
	if (bam == NULL) {
		res = -1;
		goto register_err;
	}

	tx_ep->sps = sps_alloc_endpoint();
	rx_ep->sps = sps_alloc_endpoint();
	tx_h_sps = tx_ep->sps;
	rx_h_sps = rx_ep->sps;

	res = sps_get_config(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;
	res = sps_get_config(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect TX = MEM->BAM = Consumer ----\n");
	tx_connect_options =
	SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		tx_connect_options |= SPS_O_POLL;

	tx_connect.source = SPS_DEV_HANDLE_MEM;	/* Memory */
	tx_connect.destination = h;
	tx_connect.mode = SPS_MODE_DEST;	/* Consumer pipe */
	//tx_connect.src_pipe_index = rx_pipe;
	tx_connect.dest_pipe_index = tx_pipe;
	tx_connect.event_thresh = 0x10;
	tx_connect.options = tx_connect_options;

	//tx_desc_fifo.size = 0x100;
	tx_desc_fifo.size = 0x40 + 8; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &tx_desc_fifo);
	memset(tx_desc_fifo.base, 0x00, tx_desc_fifo.size);
	tx_connect.desc = tx_desc_fifo;

	res = sps_connect(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect RX = BAM->MEM = Producer----\n");
	rx_connect_options =
	SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		rx_connect_options |= SPS_O_POLL;

	rx_connect.source = h;
	rx_connect.destination = SPS_DEV_HANDLE_MEM;	/* Memory */
	rx_connect.mode = SPS_MODE_SRC;	/* Producer pipe */
	rx_connect.src_pipe_index = rx_pipe;
	//rx_connect.dest_pipe_index = tx_pipe;
	rx_connect.event_thresh = 0x10;
	rx_connect.options = rx_connect_options;

	//rx_desc_fifo.size = 0x100;
	rx_desc_fifo.size = 0x40 + 8; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &rx_desc_fifo);
	memset(rx_desc_fifo.base, 0x00, rx_desc_fifo.size);
	rx_connect.desc = rx_desc_fifo;

	res = sps_connect(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":-----Allocate Buffers----\n");
	tx_mem.size = tx_size;
	rx_mem.size = rx_size;

	pr_info(DRV_MAME ":Allocating Data Buffers from %s.\n", mem_type);
	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */

		mem = &rx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */
	} else {
		test_alloc_mem(use_pipe_mem, &tx_mem);
		test_alloc_mem(use_pipe_mem, &rx_mem);
	}

	pr_info(DRV_MAME ":%s.tx mem phys=%pa.virt=0x%p.\n",
		__func__, &tx_mem.phys_base, tx_mem.base);
	pr_info(DRV_MAME ":%s.rx mem phys=%pa.virt=0x%p.\n",
		__func__, &rx_mem.phys_base, rx_mem.base);

	tx_buf = tx_mem.base;
	rx_buf = rx_mem.base;

	tx_event.mode = SPS_TRIGGER_CALLBACK;
	tx_event.options = SPS_O_EOT;
	tx_event.user = (void *)tx_ep;
	init_completion(&tx_ep->xfer_done);
	tx_event.xfer_done = &tx_ep->xfer_done;
	pr_info(DRV_MAME ":tx_event.event=0x%p.\n", tx_event.xfer_done);

	rx_event.mode = SPS_TRIGGER_CALLBACK;
	rx_event.options = SPS_O_EOT;
	rx_event.user = (void *)rx_ep;
	init_completion(&rx_ep->xfer_done);
	rx_event.xfer_done = &rx_ep->xfer_done;
	pr_info(DRV_MAME ":rx_event.event=0x%p.\n", rx_event.xfer_done);

	/*
	 * WARNING: MUST register reg_event to enable interrupt on the
	 * pipe level.
	 */
	res = sps_register_event(tx_h_sps, &tx_event);
	if (res)
		goto exit_err;
	res = sps_register_event(rx_h_sps, &rx_event);
	if (res)
		goto exit_err;

	if (loop_test)
		/* Each loop the tx_size is decremented by 4 */
		max_loops = (tx_size / 0x40) - 4;

	for (loop = 0; loop < max_loops; loop++) {
		init_completion(&tx_ep->xfer_done);
		init_completion(&rx_ep->xfer_done);

		pr_info(DRV_MAME ":-----Prepare Buffers----\n");

		memset(tx_buf, 0xaa, tx_mem.size);
		memset(rx_buf, 0xbb, rx_mem.size);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			mem->phys_base =
			dma_map_single(NULL, mem->base, mem->size, 0);
			mem = &rx_mem;
			mem->phys_base =
			dma_map_single(NULL, mem->base, mem->size, 0);
		}

		pr_info(DRV_MAME ":-----Start Transfers----\n");

		tx_xfer_flags = SPS_IOVEC_FLAG_EOT;

		tx_multi = (tx_desc_fifo.size / 8) - 1;

		rx_xfer_flags = 0;

		rx_multi = tx_eot_per_xfer ? tx_multi : 1;

		for (i = 0; i < rx_multi; i++) {
			u32 size = rx_size;
			u32 addr = 0;
			u32 flags = rx_xfer_flags;

			if (tx_eot_per_xfer) {
				/* for continues data in rx-buf
				 * the size *must* match the tx transfers
				 */

				size = tx_size / tx_multi;
			}
			addr = rx_mem.phys_base + i * size;

			res =
			sps_transfer_one(rx_h_sps, addr, size, rx_h_sps,
					flags);
			pr_info("sps_transfer_one rx res = %d.\n", res);
			if (res)
				goto exit_err;
		}

		//TX after RX is ready
		for (i = 0; i < tx_multi; i++) {
			u32 size = tx_size / tx_multi;
			u32 addr = tx_mem.phys_base + i * size;
			u32 flags = 0;

			if (tx_eot_per_xfer)
				/* every desc has EOT */
				flags = tx_xfer_flags;
			else
				/* only the last has EOT */
				flags = (i < tx_multi - 1) ? 0 : tx_xfer_flags;
			res =
			sps_transfer_one(tx_h_sps, addr, size, tx_h_sps,
					flags);
			pr_info("sps_transfer_one tx res = %d.\n", res);
			if (res)
				goto exit_err;
		}

		pr_info(DRV_MAME ":-----Wait Transfers Complete----\n");

		msleep(10); /* allow transfer to complete */

		/* output register info */
		print_bam_reg(bam);
		print_bam_pipe_reg(bam, tx_pipe);
		print_bam_pipe_reg(bam, rx_pipe);

		/* output desc FIFO content */
		desc = tx_desc_fifo.base;
		pr_info("tx desc-fifo at %pa:\n", &tx_desc_fifo.phys_base);
		for (i = 0; i < (tx_desc_fifo.size / 8); i++)
			pr_info("%d:0x%lx,0x%lx.\n", i, desc[i * 2],
				desc[i * 2 + 1]);

		desc = rx_desc_fifo.base;
		pr_info("rx desc-fifo at %pa:\n", &rx_desc_fifo.phys_base);
		for (i = 0; i < (rx_desc_fifo.size / 8); i++)
			pr_info("%d:0x%lx,0x%lx.\n", i, desc[i * 2],
				desc[i * 2 + 1]);


		/* wait for interrupt or check if the transfer is complete on RX pipe */
		res = wait_xfer_completion(use_irq, &rx_ep->xfer_done,
					   rx_h_sps, rx_multi, 3, 0);

		if (res) {
			pr_err(DRV_MAME ":%s:transfer is not completed.\n",
			       __func__);
			goto exit_err;
		}

		for (i = 0; i < tx_multi; i++) {
			sps_get_iovec(tx_ep->sps, &tx_ep->IOVec);
			total_tx_size += tx_ep->IOVec.size;
		}

		for (i = 0; i < rx_multi; i++) {
			sps_get_iovec(rx_ep->sps, &rx_ep->IOVec);
			total_rx_size += rx_ep->IOVec.size;
		}

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
			mem = &rx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
		}

		tx_iovec = tx_ep->IOVec;
		rx_iovec = rx_ep->IOVec;

		pr_info(DRV_MAME ":-----Check Pass/Fail----\n");

		pr_info("sps_get_iovec total_tx_size = %d.\n", total_tx_size);
		pr_info("sps_get_iovec total_rx_size = %d.\n", total_rx_size);

		pr_info("tx buf[0] = 0x%lx.\n", tx_buf[0]);
		pr_info("rx buf[0] = 0x%lx.\n", rx_buf[0]);
		pr_info("tx buf[tx_size/8-1] = 0x%lx.\n",
			tx_buf[tx_size / 8 - 1]);
		pr_info("rx buf[tx_size/8-1] = 0x%lx.\n",
			rx_buf[tx_size / 8 - 1]);

		/* NOTE: Rx according to Tx size with EOT. */
		if ((total_tx_size == tx_size) &&
		    (total_rx_size == tx_size) &&
		    (tx_buf[0] == rx_buf[0]) &&
		    (tx_buf[tx_size / 8 - 1] == rx_buf[tx_size / 8 - 1])
		   ) {
			res = 0;
			if (loop_test)
				pr_info("sps:loop#%d PASS.\n", loop);
		} else {
			res = -1;
			break;
		}

		if (loop_test)
			tx_size -= 0x40;
	}

exit_err:

	pr_info(DRV_MAME ":-----Tear Down----\n");

	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		kfree(mem->base);
		mem = &rx_mem;
		kfree(mem->base);
	} else {
		test_free_mem(use_pipe_mem, &tx_mem);
		test_free_mem(use_pipe_mem, &rx_mem);
	}

	test_free_mem(use_pipe_mem, &tx_desc_fifo);
	test_free_mem(use_pipe_mem, &rx_desc_fifo);

	sps_disconnect(tx_h_sps);
	sps_disconnect(rx_h_sps);

	deregister_bam(bam, h);

register_err:
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
	if (res == 0)
		pr_info("SPS #%d BAM-DMA MULTI Test %s DESC %s - PASS.\n",
			sps_test_num, irq_mode, mem_type);
	else
		pr_info("SPS #%d BAM-DMA MULTI Test %s DESC %s - FAIL.\n",
			sps_test_num, irq_mode, mem_type);
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	return res;
}	/* MULTI */


static int sps_test_PIPE_HRESP_ERR_IRQ(int use_irq,
			    int use_pipe_mem,
			    int use_cache_mem_data_buf,
			    int loop_test)
{
	int res = 0;

	struct test_endpoint test_ep[2];
	struct test_endpoint *tx_ep = &test_ep[0];
	struct test_endpoint *rx_ep = &test_ep[1];

	void *bam = NULL;
	unsigned long h = 0;
	struct sps_connect tx_connect = { 0};
	struct sps_connect rx_connect = { 0};

	struct sps_mem_buffer tx_desc_fifo = { 0};
	struct sps_mem_buffer rx_desc_fifo = { 0};

	struct sps_mem_buffer tx_mem = { 0};
	struct sps_mem_buffer rx_mem = { 0};

	struct sps_pipe *tx_h_sps = NULL;
	struct sps_pipe *rx_h_sps = NULL;

	struct sps_iovec tx_iovec = { 0};
	struct sps_iovec rx_iovec = { 0};
	unsigned long *desc = NULL;
	unsigned long *tx_buf = NULL;
	unsigned long *rx_buf = NULL;

	u32 tx_pipe = 4;
	u32 rx_pipe = 5;

	u32 tx_xfer_flags = 0;
	u32 rx_xfer_flags = 0;

	struct sps_register_event tx_event = { 0};
	struct sps_register_event rx_event = { 0};

	u32 tx_size = 0x400;
	u32 rx_size = 0x800;	/* This the max size and not the actual size */

	u32 tx_connect_options = 0;
	u32 rx_connect_options = 0;
	char *irq_mode = use_irq ? "IRQ mode" : "Polling mode";
	char *mem_type = use_pipe_mem ? "Pipe-Mem" : "Sys-Mem";
	int loop = 0;
	int max_loops = 1;

	memset(test_ep, 0, sizeof(test_ep));
	tx_ep->signature = TEST_SIGNATURE;
	rx_ep->signature = TEST_SIGNATURE;

	pr_info(DRV_MAME ":----Register BAM ----\n");

	bam = register_bam(&h, use_irq);
	if (bam == NULL) {
		res = -1;
		goto register_err;
	}

	tx_ep->sps = sps_alloc_endpoint();
	rx_ep->sps = sps_alloc_endpoint();
	tx_h_sps = tx_ep->sps;
	rx_h_sps = rx_ep->sps;

	res = sps_get_config(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;
	res = sps_get_config(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect TX = MEM->BAM = Consumer ----\n");
	tx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT |
			SPS_O_ACK_TRANSFERS | SPS_O_HRESP_ERROR;
	if (!use_irq)
		tx_connect_options |= SPS_O_POLL;

	tx_connect.source = SPS_DEV_HANDLE_MEM;	/* Memory */
	tx_connect.destination = h;
	tx_connect.mode = SPS_MODE_DEST;	/* Consumer pipe */
	//tx_connect.src_pipe_index = rx_pipe;
	tx_connect.dest_pipe_index = tx_pipe;
	tx_connect.event_thresh = 0x10;
	tx_connect.options = tx_connect_options;

	//tx_desc_fifo.size = 0x100;
	tx_desc_fifo.size = 0x40; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &tx_desc_fifo);
	memset(tx_desc_fifo.base, 0x00, tx_desc_fifo.size);
	tx_connect.desc = tx_desc_fifo;

	res = sps_connect(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect RX = BAM->MEM = Producer----\n");
	rx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT |
			SPS_O_ACK_TRANSFERS | SPS_O_HRESP_ERROR;
	if (!use_irq)
		rx_connect_options |= SPS_O_POLL;

	rx_connect.source = h;
	rx_connect.destination = SPS_DEV_HANDLE_MEM;	/* Memory */
	rx_connect.mode = SPS_MODE_SRC;	/* Producer pipe */
	rx_connect.src_pipe_index = rx_pipe;
	//rx_connect.dest_pipe_index = tx_pipe;
	rx_connect.event_thresh = 0x10;
	rx_connect.options = rx_connect_options;

	/* rx_desc_fifo.size = 0x100; */
	rx_desc_fifo.size = 0x40; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &rx_desc_fifo);
	memset(rx_desc_fifo.base, 0x00, rx_desc_fifo.size);
	rx_connect.desc = rx_desc_fifo;

	res = sps_connect(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":-----Allocate Buffers----\n");
	tx_mem.size = tx_size;
	rx_mem.size = rx_size;

	pr_info(DRV_MAME ":Allocating Data Buffers from %s.\n", mem_type);
	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */

		mem = &rx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */
	} else {
		test_alloc_mem(use_pipe_mem, &tx_mem);
		test_alloc_mem(use_pipe_mem, &rx_mem);
	}

	pr_info(DRV_MAME ":%s.tx mem phys=%pa.virt=0x%p.\n",
		__func__, &tx_mem.phys_base, tx_mem.base);
	pr_info(DRV_MAME ":%s.rx mem phys=%pa.virt=0x%p.\n",
		__func__, &rx_mem.phys_base, rx_mem.base);

	tx_buf = tx_mem.base;
	rx_buf = rx_mem.base;

	tx_event.mode = SPS_TRIGGER_CALLBACK;
	tx_event.options = SPS_O_EOT | SPS_O_HRESP_ERROR;
	tx_event.user = (void *)tx_ep;
	init_completion(&tx_ep->xfer_done);
	tx_event.xfer_done = &tx_ep->xfer_done;
	tx_event.callback = tx_event_callback_notify;
	pr_info(DRV_MAME ":tx_event.event=0x%p.\n", tx_event.xfer_done);

	rx_event.mode = SPS_TRIGGER_CALLBACK;
	rx_event.options = SPS_O_EOT | SPS_O_HRESP_ERROR;
	rx_event.user = (void *)rx_ep;
	init_completion(&rx_ep->xfer_done);
	rx_event.xfer_done = &rx_ep->xfer_done;
	rx_event.callback = rx_event_callback_notify;
	pr_info(DRV_MAME ":rx_event.event=0x%p.\n", rx_event.xfer_done);

	/* WARNING: MUST register reg_event to enable interrupt
	   on the pipe level. */
	res = sps_register_event(tx_h_sps, &tx_event);
	if (res)
		goto exit_err;
	res = sps_register_event(rx_h_sps, &rx_event);
	if (res)
		goto exit_err;

	if (loop_test) {
		max_loops = tx_size / 0x40;
		pr_info(DRV_MAME ":----- Start testing for %d loops ----\n", max_loops);
	}

	for (loop = 0; loop < max_loops; loop++) {
		init_completion(&tx_ep->xfer_done);
		init_completion(&rx_ep->xfer_done);

		pr_info(DRV_MAME ":-----Prepare Buffers----\n");

		memset(tx_buf, 0xaa, tx_mem.size);
		memset(rx_buf, 0xbb, rx_mem.size);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
			mem = &rx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
		}

		pr_info(DRV_MAME ":-----Start Transfers----\n");

		rx_xfer_flags = 0;
		res = sps_transfer_one(rx_h_sps, rx_mem.phys_base, rx_size,
				       rx_h_sps, rx_xfer_flags);
		pr_info("sps_transfer_one rx res = %d.\n", res);
		if (res)
			goto exit_err;

		tx_xfer_flags =	SPS_IOVEC_FLAG_EOT;
		res = sps_transfer_one(tx_h_sps, 0xFFFFFFFF, tx_size,
				       tx_h_sps, tx_xfer_flags);

		pr_info("sps_transfer_one tx res = %d.\n", res);
		if (res)
			goto exit_err;


		pr_info(DRV_MAME ":-----Wait Transfers Complete----\n");

		msleep(10); /* allow transfer to complete */

		/* output register info */
		print_bam_reg(bam);
		print_bam_pipe_reg(bam, tx_pipe);
		print_bam_pipe_reg(bam, rx_pipe);

		/* output desc FIFO content */
		desc = tx_desc_fifo.base;
		pr_info("tx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&tx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);
		desc = rx_desc_fifo.base;
		pr_info("rx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&rx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);

		/* wait for interrupt or check if the transfer is complete on RX pipe */
		res = wait_xfer_completion(use_irq, &rx_ep->xfer_done,
					   rx_h_sps, 1, 3, 0);

		if (res) {
			pr_err("sps_test:%s.transfer is not completed.\n",
			       __func__);
			goto exit_err;
		}

		sps_get_iovec(tx_ep->sps, &tx_ep->IOVec);
		sps_get_iovec(rx_ep->sps, &rx_ep->IOVec);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
			mem = &rx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
		}

		tx_iovec = tx_ep->IOVec;
		rx_iovec = rx_ep->IOVec;

		pr_info(DRV_MAME ":-----Check Pass/Fail----\n");

		pr_info("sps_get_iovec tx size = %d.\n", tx_iovec.size);
		pr_info("sps_get_iovec rx size = %d.\n", rx_iovec.size);

		pr_info("tx buf[0] = 0x%lx.\n", tx_buf[0]);
		pr_info("rx buf[0] = 0x%lx.\n", rx_buf[0]);
		pr_info("tx buf[tx_size/8-1] = 0x%lx.\n",
			tx_buf[tx_size / 8 - 1]);
		pr_info("rx buf[tx_size/8-1] = 0x%lx.\n",
			rx_buf[tx_size / 8 - 1]);

		/* NOTE: Rx according to Tx size with EOT. */
		if ((tx_iovec.size == tx_size) &&
		    (rx_iovec.size == tx_size) &&
		    (tx_buf[0] == rx_buf[0]) &&
		    (tx_buf[tx_size / 8 - 1] == rx_buf[tx_size / 8 - 1])
		   ) {
			res = 0;
			if (loop_test)
				pr_info("sps:No. %d loop PASS.\n", loop + 1);
		} else {
			res = -1;
			break;
		}

		if (loop_test)
			tx_size -= 0x40;
	}

exit_err:

	pr_info(DRV_MAME ":-----Tear Down----\n");

	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		kfree(mem->base);
		mem = &rx_mem;
		kfree(mem->base);
	} else {
		test_free_mem(use_pipe_mem, &tx_mem);
		test_free_mem(use_pipe_mem, &rx_mem);
	}
	test_free_mem(use_pipe_mem, &tx_desc_fifo);
	test_free_mem(use_pipe_mem, &rx_desc_fifo);

	sps_disconnect(tx_h_sps);
	sps_disconnect(rx_h_sps);

	deregister_bam(bam, h);

register_err:
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
	if (res == 0)
		pr_info("SPS #%d PIPE_HRESP_ERR_IRQ Test %s DESC %s - PASS.\n",
			sps_test_num, irq_mode, mem_type);
	else
		pr_info("SPS #%d PIPE_HRESP_ERR_IRQ Test %s DESC %s - FAIL.\n",
			sps_test_num, irq_mode, mem_type);
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	return res;
}
/* test HRESP_ERR_IRQ single transfer */

/* test HRESP_ERR_IRQ  single transfer */
static int sps_test_HRESP_ERR_IRQ(int use_irq,
			    int use_pipe_mem,
			    int use_cache_mem_data_buf,
			    int loop_test)
{
	int res = 0;

	struct test_endpoint test_ep[2];
	struct test_endpoint *tx_ep = &test_ep[0];
	struct test_endpoint *rx_ep = &test_ep[1];

	void *bam = NULL;
	unsigned long h = 0;
	struct sps_connect tx_connect = { 0};
	struct sps_connect rx_connect = { 0};

	struct sps_mem_buffer tx_desc_fifo = { 0};
	struct sps_mem_buffer rx_desc_fifo = { 0};

	struct sps_mem_buffer tx_mem = { 0};
	struct sps_mem_buffer rx_mem = { 0};

	struct sps_pipe *tx_h_sps = NULL;
	struct sps_pipe *rx_h_sps = NULL;

	struct sps_iovec tx_iovec = { 0};
	struct sps_iovec rx_iovec = { 0};
	unsigned long *desc = NULL;
	unsigned long *tx_buf = NULL;
	unsigned long *rx_buf = NULL;

	u32 tx_pipe = 4;
	u32 rx_pipe = 5;

	u32 tx_xfer_flags = 0;
	u32 rx_xfer_flags = 0;

	struct sps_register_event tx_event = { 0};
	struct sps_register_event rx_event = { 0};

	u32 tx_size = 0x400;
	u32 rx_size = 0x800;	/* This the max size and not the actual size */

	u32 tx_connect_options = 0;
	u32 rx_connect_options = 0;
	char *irq_mode = use_irq ? "IRQ mode" : "Polling mode";
	char *mem_type = use_pipe_mem ? "Pipe-Mem" : "Sys-Mem";
	int loop = 0;
	int max_loops = 1;

	memset(test_ep, 0, sizeof(test_ep));
	tx_ep->signature = TEST_SIGNATURE;
	rx_ep->signature = TEST_SIGNATURE;

	pr_info(DRV_MAME ":----Register BAM ----\n");

	bam = register_bam(&h, use_irq);
	if (bam == NULL) {
		res = -1;
		goto register_err;
	}

	tx_ep->sps = sps_alloc_endpoint();
	rx_ep->sps = sps_alloc_endpoint();
	tx_h_sps = tx_ep->sps;
	rx_h_sps = rx_ep->sps;

	res = sps_get_config(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;
	res = sps_get_config(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect TX = MEM->BAM = Consumer ----\n");
	tx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		tx_connect_options |= SPS_O_POLL;

	tx_connect.source = SPS_DEV_HANDLE_MEM;	/* Memory */
	tx_connect.destination = h;
	tx_connect.mode = SPS_MODE_DEST;	/* Consumer pipe */
	//tx_connect.src_pipe_index = rx_pipe;
	tx_connect.dest_pipe_index = tx_pipe;
	tx_connect.event_thresh = 0x10;
	tx_connect.options = tx_connect_options;

	//tx_desc_fifo.size = 0x100;
	tx_desc_fifo.size = 0x40; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &tx_desc_fifo);
	memset(tx_desc_fifo.base, 0x00, tx_desc_fifo.size);
	tx_connect.desc = tx_desc_fifo;

	res = sps_connect(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect RX = BAM->MEM = Producer----\n");
	rx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		rx_connect_options |= SPS_O_POLL;

	rx_connect.source = h;
	rx_connect.destination = SPS_DEV_HANDLE_MEM;	/* Memory */
	rx_connect.mode = SPS_MODE_SRC;	/* Producer pipe */
	rx_connect.src_pipe_index = rx_pipe;
	//rx_connect.dest_pipe_index = tx_pipe;
	rx_connect.event_thresh = 0x10;
	rx_connect.options = rx_connect_options;

	/* rx_desc_fifo.size = 0x100; */
	rx_desc_fifo.size = 0x40; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &rx_desc_fifo);
	memset(rx_desc_fifo.base, 0x00, rx_desc_fifo.size);
	rx_connect.desc = rx_desc_fifo;

	res = sps_connect(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":-----Allocate Buffers----\n");
	tx_mem.size = tx_size;
	rx_mem.size = rx_size;

	pr_info(DRV_MAME ":Allocating Data Buffers from %s.\n", mem_type);
	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */

		mem = &rx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */
	} else {
		test_alloc_mem(use_pipe_mem, &tx_mem);
		test_alloc_mem(use_pipe_mem, &rx_mem);
	}

	pr_info(DRV_MAME ":%s.tx mem phys=%pa.virt=0x%p.\n",
		__func__, &tx_mem.phys_base, tx_mem.base);
	pr_info(DRV_MAME ":%s.rx mem phys=%pa.virt=0x%p.\n",
		__func__, &rx_mem.phys_base, rx_mem.base);

	tx_buf = tx_mem.base;
	rx_buf = rx_mem.base;

	tx_event.mode = SPS_TRIGGER_CALLBACK;
	tx_event.options = SPS_O_EOT;
	tx_event.user = (void *)tx_ep;
	init_completion(&tx_ep->xfer_done);
	tx_event.xfer_done = &tx_ep->xfer_done;
	pr_info(DRV_MAME ":tx_event.event=0x%p.\n", tx_event.xfer_done);

	rx_event.mode = SPS_TRIGGER_CALLBACK;
	rx_event.options = SPS_O_EOT;
	rx_event.user = (void *)rx_ep;
	init_completion(&rx_ep->xfer_done);
	rx_event.xfer_done = &rx_ep->xfer_done;
	pr_info(DRV_MAME ":rx_event.event=0x%p.\n", rx_event.xfer_done);

	/* WARNING: MUST register reg_event to enable interrupt
	   on the pipe level. */
	res = sps_register_event(tx_h_sps, &tx_event);
	if (res)
		goto exit_err;
	res = sps_register_event(rx_h_sps, &rx_event);
	if (res)
		goto exit_err;

	if (loop_test) {
		max_loops = tx_size / 0x40;
		pr_info(DRV_MAME ":----- Start testing for %d loops ----\n", max_loops);
	}

	for (loop = 0; loop < max_loops; loop++) {
		init_completion(&tx_ep->xfer_done);
		init_completion(&rx_ep->xfer_done);

		pr_info(DRV_MAME ":-----Prepare Buffers----\n");

		memset(tx_buf, 0xaa, tx_mem.size);
		memset(rx_buf, 0xbb, rx_mem.size);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
			mem = &rx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
		}

		pr_info(DRV_MAME ":-----Start Transfers----\n");

		rx_xfer_flags = 0;
		res = sps_transfer_one(rx_h_sps, rx_mem.phys_base, rx_size,
				       rx_h_sps, rx_xfer_flags);
		pr_info("sps_transfer_one rx res = %d.\n", res);
		if (res)
			goto exit_err;

		tx_xfer_flags =	SPS_IOVEC_FLAG_EOT;
		res = sps_transfer_one(tx_h_sps, 0xF9999000, tx_size,
				       tx_h_sps, tx_xfer_flags);

		pr_info("sps_transfer_one tx res = %d.\n", res);
		if (res)
			goto exit_err;


		pr_info(DRV_MAME ":-----Wait Transfers Complete----\n");

		msleep(10); /* allow transfer to complete */

		/* output register info */
		print_bam_reg(bam);
		print_bam_pipe_reg(bam, tx_pipe);
		print_bam_pipe_reg(bam, rx_pipe);

		/* output desc FIFO content */
		desc = tx_desc_fifo.base;
		pr_info("tx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&tx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);
		desc = rx_desc_fifo.base;
		pr_info("rx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&rx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);

		/* wait for interrupt or check if the transfer is complete on RX pipe */
		res = wait_xfer_completion(use_irq, &rx_ep->xfer_done,
					   rx_h_sps, 1, 3, 0);

		if (res) {
			pr_err("sps_test:%s.transfer is not completed.\n",
			       __func__);
			goto exit_err;
		}

		sps_get_iovec(tx_ep->sps, &tx_ep->IOVec);
		sps_get_iovec(rx_ep->sps, &rx_ep->IOVec);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
			mem = &rx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
		}

		tx_iovec = tx_ep->IOVec;
		rx_iovec = rx_ep->IOVec;

		pr_info(DRV_MAME ":-----Check Pass/Fail----\n");

		pr_info("sps_get_iovec tx size = %d.\n", tx_iovec.size);
		pr_info("sps_get_iovec rx size = %d.\n", rx_iovec.size);

		pr_info("tx buf[0] = 0x%lx.\n", tx_buf[0]);
		pr_info("rx buf[0] = 0x%lx.\n", rx_buf[0]);
		pr_info("tx buf[tx_size/8-1] = 0x%lx.\n",
			tx_buf[tx_size / 8 - 1]);
		pr_info("rx buf[tx_size/8-1] = 0x%lx.\n",
			rx_buf[tx_size / 8 - 1]);

		/* NOTE: Rx according to Tx size with EOT. */
		if ((tx_iovec.size == tx_size) &&
		    (rx_iovec.size == tx_size) &&
		    (tx_buf[0] == rx_buf[0]) &&
		    (tx_buf[tx_size / 8 - 1] == rx_buf[tx_size / 8 - 1])
		   ) {
			res = 0;
			if (loop_test)
				pr_info("sps:No. %d loop PASS.\n", loop + 1);
		} else {
			res = -1;
			break;
		}

		if (loop_test)
			tx_size -= 0x40;
	}

exit_err:

	pr_info(DRV_MAME ":-----Tear Down----\n");

	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		kfree(mem->base);
		mem = &rx_mem;
		kfree(mem->base);
	} else {
		test_free_mem(use_pipe_mem, &tx_mem);
		test_free_mem(use_pipe_mem, &rx_mem);
	}
	test_free_mem(use_pipe_mem, &tx_desc_fifo);
	test_free_mem(use_pipe_mem, &rx_desc_fifo);

	sps_disconnect(tx_h_sps);
	sps_disconnect(rx_h_sps);

	deregister_bam(bam, h);

register_err:
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
	if (res == 0)
		pr_info("SPS #%d HRESP_ERR_IRQ Test %s DESC %s - PASS.\n",
			sps_test_num, irq_mode, mem_type);
	else
		pr_info("SPS #%d HRESP_ERR_IRQ Test %s DESC %s - FAIL.\n",
			sps_test_num, irq_mode, mem_type);
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	return res;
}
/* test HRESP_ERR_IRQ single transfer */


/* test sps_transfer (BAM-to-System mode) */
static int sps_test_sps_transfer(int use_irq,
			    int use_pipe_mem)
{
	int res = 0;

	struct test_endpoint test_ep[2];
	struct test_endpoint *tx_ep = &test_ep[0];
	struct test_endpoint *rx_ep = &test_ep[1];

	void *bam = NULL;
	unsigned long h = 0;
	struct sps_connect tx_connect = { 0};
	struct sps_connect rx_connect = { 0};

	struct sps_mem_buffer tx_desc_fifo = { 0};
	struct sps_mem_buffer rx_desc_fifo = { 0};

	struct sps_mem_buffer tx_mem = { 0};
	struct sps_mem_buffer rx_mem = { 0};

	struct sps_pipe *tx_h_sps = NULL;
	struct sps_pipe *rx_h_sps = NULL;

	struct sps_transfer tx_transfer;
	struct sps_transfer rx_transfer;

	u32 size_of_each_block;
	dma_addr_t dma_addr;
	int i;

	unsigned long *tx_buf = NULL;
	unsigned long *rx_buf = NULL;

	u32 total_tx_size = 0;
	u32 total_rx_size = 0;

	u32 tx_pipe = 4;
	u32 rx_pipe = 5;

	u32 tx_xfer_flags = 0;
	u32 rx_xfer_flags = 0;

	struct sps_register_event tx_event = { 0};
	struct sps_register_event rx_event = { 0};

	u32 tx_size = 0x700;
	u32 rx_size = 0x700;

	u32 tx_connect_options = 0;
	u32 rx_connect_options = 0;
	char *irq_mode = use_irq ? "IRQ mode" : "Polling mode";
	char *mem_type = use_pipe_mem ? "Pipe-Mem" : "Sys-Mem";

	memset(test_ep, 0, sizeof(test_ep));
	tx_ep->signature = TEST_SIGNATURE;
	rx_ep->signature = TEST_SIGNATURE;

	pr_info(DRV_MAME ":----Register BAM ----\n");

	bam = register_bam(&h, use_irq);
	if (bam == NULL) {
		res = -1;
		goto register_err;
	}

	tx_ep->sps = sps_alloc_endpoint();
	rx_ep->sps = sps_alloc_endpoint();
	tx_h_sps = tx_ep->sps;
	rx_h_sps = rx_ep->sps;

	res = sps_get_config(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;
	res = sps_get_config(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect TX = MEM->BAM = Consumer ----\n");
	tx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		tx_connect_options |= SPS_O_POLL;

	tx_connect.source = SPS_DEV_HANDLE_MEM;	/* Memory */
	tx_connect.destination = h;
	tx_connect.mode = SPS_MODE_DEST;	/* Consumer pipe */
	tx_connect.dest_pipe_index = tx_pipe;
	tx_connect.event_thresh = 0x10;
	tx_connect.options = tx_connect_options;

	tx_desc_fifo.size = 0x40;
	test_alloc_mem(use_pipe_mem, &tx_desc_fifo);
	memset(tx_desc_fifo.base, 0x00, tx_desc_fifo.size);
	tx_connect.desc = tx_desc_fifo;

	res = sps_connect(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect RX = BAM->MEM = Producer----\n");
	rx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		rx_connect_options |= SPS_O_POLL;

	rx_connect.source = h;
	rx_connect.destination = SPS_DEV_HANDLE_MEM;	/* Memory */
	rx_connect.mode = SPS_MODE_SRC;	/* Producer pipe */
	rx_connect.src_pipe_index = rx_pipe;
	rx_connect.event_thresh = 0x10;
	rx_connect.options = rx_connect_options;

	rx_desc_fifo.size = 0x40;
	test_alloc_mem(use_pipe_mem, &rx_desc_fifo);
	memset(rx_desc_fifo.base, 0x00, rx_desc_fifo.size);
	rx_connect.desc = rx_desc_fifo;

	res = sps_connect(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":Allocating Data Buffers from %s.\n", mem_type);

	tx_mem.size = tx_size;
	rx_mem.size = rx_size;

	test_alloc_mem(use_pipe_mem, &tx_mem);
	test_alloc_mem(use_pipe_mem, &rx_mem);

	pr_info(DRV_MAME ":%s.tx mem phys=%pa.virt=0x%p.\n",
		__func__, &tx_mem.phys_base, tx_mem.base);
	pr_info(DRV_MAME ":%s.rx mem phys=%pa.virt=0x%p.\n",
		__func__, &rx_mem.phys_base, rx_mem.base);

	tx_buf = tx_mem.base;
	rx_buf = rx_mem.base;

	tx_event.mode = SPS_TRIGGER_CALLBACK;
	tx_event.options = SPS_O_EOT;
	tx_event.user = (void *)tx_ep;
	init_completion(&tx_ep->xfer_done);
	tx_event.xfer_done = &tx_ep->xfer_done;
	pr_info(DRV_MAME ":tx_event.event=0x%p.\n", tx_event.xfer_done);

	rx_event.mode = SPS_TRIGGER_CALLBACK;
	rx_event.options = SPS_O_EOT;
	rx_event.user = (void *)rx_ep;
	init_completion(&rx_ep->xfer_done);
	rx_event.xfer_done = &rx_ep->xfer_done;
	pr_info(DRV_MAME ":rx_event.event=0x%p.\n", rx_event.xfer_done);

	/* WARNING: MUST register reg_event to enable interrupt
	   on the pipe level. */
	res = sps_register_event(tx_h_sps, &tx_event);
	if (res)
		goto exit_err;
	res = sps_register_event(rx_h_sps, &rx_event);
	if (res)
		goto exit_err;


	pr_info(DRV_MAME ":-----Init Data Buffers----\n");

	memset(tx_buf, 0xaa, tx_mem.size);
	memset(rx_buf, 0xbb, rx_mem.size);

	pr_info(DRV_MAME ":-----Prepare descriptors on TX pipe ----\n");
	tx_transfer.user = tx_h_sps;
	tx_transfer.iovec_count = 7; /* because desc_fifo.size = 0x40 */
	tx_transfer.iovec = (struct sps_iovec *) dma_alloc_coherent(sps_test->dev,
							tx_transfer.iovec_count * sizeof(struct sps_iovec),
							&dma_addr, GFP_KERNEL);
	tx_transfer.iovec_phys = dma_addr;

	size_of_each_block = tx_size / tx_transfer.iovec_count; /* 0x100 bytes */
	tx_xfer_flags =	SPS_IOVEC_FLAG_EOT;

	for (i = 0; i < tx_transfer.iovec_count; i++) {
		struct sps_iovec *iovec = tx_transfer.iovec + i;
		iovec->size = size_of_each_block;
		iovec->addr = tx_mem.phys_base + i * size_of_each_block;
		if (i == (tx_transfer.iovec_count - 1))
			iovec->flags = tx_xfer_flags;
	}

	pr_info(DRV_MAME ":-----Prepare descriptors on RX pipe ----\n");
	rx_transfer.user = rx_h_sps;
	rx_transfer.iovec_count = 7; /* because desc_fifo.size = 0x40 */
	rx_transfer.iovec = (struct sps_iovec *) dma_alloc_coherent(sps_test->dev,
							rx_transfer.iovec_count * sizeof(struct sps_iovec),
							&dma_addr, GFP_KERNEL);
	rx_transfer.iovec_phys = dma_addr;

	size_of_each_block = rx_size / rx_transfer.iovec_count; /* 0x100 bytes */
	rx_xfer_flags = 0;

	for (i = 0; i < rx_transfer.iovec_count; i++) {
		struct sps_iovec *iovec = rx_transfer.iovec + i;
		iovec->size = size_of_each_block;
		iovec->addr = rx_mem.phys_base + i * size_of_each_block;
		iovec->flags = rx_xfer_flags;
	}

	pr_info(DRV_MAME ":-----Start Transfers----\n");

	res = sps_transfer(rx_h_sps, &rx_transfer);
	pr_info("sps_transfer rx res = %d.\n", res);
	if (res)
		goto exit_err;


	res = sps_transfer(tx_h_sps, &tx_transfer);
	pr_info("sps_transfer tx res = %d.\n", res);
	if (res)
		goto exit_err;


	pr_info(DRV_MAME ":-----Wait Transfers Complete----\n");

	msleep(10); /* allow transfer to complete */

	/* output register and desc FIFO content */
	print_BAM_reg_and_desc_FIFO(bam, tx_pipe, rx_pipe, 32, 32,
					tx_desc_fifo, rx_desc_fifo,
					tx_desc_fifo, rx_desc_fifo);

	/* wait for interrupt or check if the transfer is complete on RX pipe */
	res = wait_xfer_completion(use_irq, &rx_ep->xfer_done,
				   rx_h_sps, 1, 3, 0);

	if (res) {
		pr_err("sps_test:%s.transfer is not completed.\n",
		       __func__);
		goto exit_err;
	}

	for (i = 0; i < tx_transfer.iovec_count; i++) {
		sps_get_iovec(tx_ep->sps, &tx_ep->IOVec);
		total_tx_size += tx_ep->IOVec.size;
	}

	for (i = 0; i < rx_transfer.iovec_count; i++) {
		sps_get_iovec(rx_ep->sps, &rx_ep->IOVec);
		total_rx_size += rx_ep->IOVec.size;
	}

	pr_info(DRV_MAME ":-----Check Pass/Fail----\n");

	pr_info("sps_get_iovec total_tx_size = %d.\n", total_tx_size);
	pr_info("sps_get_iovec total_rx_size = %d.\n", total_rx_size);

	pr_info("tx buf[0] = 0x%lx.\n", tx_buf[0]);
	pr_info("rx buf[0] = 0x%lx.\n", rx_buf[0]);
	pr_info("tx buf[tx_size/8-1] = 0x%lx.\n",
		tx_buf[tx_size / 8 - 1]);
	pr_info("rx buf[tx_size/8-1] = 0x%lx.\n",
		rx_buf[tx_size / 8 - 1]);

	/* NOTE: Rx according to Tx size with EOT. */
	if ((total_tx_size == tx_size) &&
	    (total_rx_size == tx_size) &&
	    (tx_buf[0] == rx_buf[0]) &&
	    (tx_buf[tx_size / 8 - 1] == rx_buf[tx_size / 8 - 1])
	   ) {
		res = 0;
	} else
		res = -1;


exit_err:

	pr_info(DRV_MAME ":-----Tear Down----\n");

	dma_addr = tx_transfer.iovec_phys;
	if (dma_addr)
		dma_free_coherent(NULL, tx_transfer.iovec_count * sizeof(struct sps_iovec),
						(void *)tx_transfer.iovec, dma_addr);
	dma_addr = rx_transfer.iovec_phys;
	if (dma_addr)
		dma_free_coherent(NULL, rx_transfer.iovec_count * sizeof(struct sps_iovec),
						(void *)rx_transfer.iovec, dma_addr);

	test_free_mem(use_pipe_mem, &tx_mem);
	test_free_mem(use_pipe_mem, &rx_mem);

	test_free_mem(use_pipe_mem, &tx_desc_fifo);
	test_free_mem(use_pipe_mem, &rx_desc_fifo);

	sps_disconnect(tx_h_sps);
	sps_disconnect(rx_h_sps);

	deregister_bam(bam, h);

register_err:
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
	if (res == 0)
		pr_info("SPS #%d BAM-DMA test sps_transfer %s DESC %s - PASS.\n",
			sps_test_num, irq_mode, mem_type);
	else
		pr_info("SPS #%d BAM-DMA test sps_transfer %s DESC %s - FAIL.\n",
			sps_test_num, irq_mode, mem_type);
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	return res;
}	/* test sps_transfer */


/* temp test for register dump API */
static int sps_test_sys2bam_with_dump(int use_irq,
			    int use_pipe_mem,
			    int use_cache_mem_data_buf,
			    int loop_test,
			    u32 option,
			    u32 para,
			    u32 tb_sel,
			    u32 desc_sel)
{
	int res = 0;

	struct test_endpoint test_ep[2];
	struct test_endpoint *tx_ep = &test_ep[0];
	struct test_endpoint *rx_ep = &test_ep[1];

	void *bam = NULL;
	unsigned long h = 0;
	struct sps_connect tx_connect = { 0};
	struct sps_connect rx_connect = { 0};

	struct sps_mem_buffer tx_desc_fifo = { 0};
	struct sps_mem_buffer rx_desc_fifo = { 0};

	struct sps_mem_buffer tx_mem = { 0};
	struct sps_mem_buffer rx_mem = { 0};

	struct sps_pipe *tx_h_sps = NULL;
	struct sps_pipe *rx_h_sps = NULL;

	struct sps_iovec tx_iovec = { 0};
	struct sps_iovec rx_iovec = { 0};
	unsigned long *desc = NULL;
	unsigned long *tx_buf = NULL;
	unsigned long *rx_buf = NULL;

	u32 tx_pipe = 4;
	u32 rx_pipe = 5;

	u32 tx_xfer_flags = 0;
	u32 rx_xfer_flags = 0;

	struct sps_register_event tx_event = { 0};
	struct sps_register_event rx_event = { 0};

	u32 tx_size = 0x400;
	u32 rx_size = 0x400;	/* This the max size and not the actual size */

	u32 tx_connect_options = 0;
	u32 rx_connect_options = 0;
	char *irq_mode = use_irq ? "IRQ mode" : "Polling mode";
	char *mem_type = use_pipe_mem ? "Pipe-Mem" : "Sys-Mem";
	int loop = 0;
	int max_loops = 1;
	int i;

	memset(test_ep, 0, sizeof(test_ep));
	tx_ep->signature = TEST_SIGNATURE;
	rx_ep->signature = TEST_SIGNATURE;

	pr_info(DRV_MAME ":----Register BAM ----\n");

	bam = register_bam(&h, use_irq);
	if (bam == NULL) {
		res = -1;
		goto register_err;
	}

	tx_ep->sps = sps_alloc_endpoint();
	rx_ep->sps = sps_alloc_endpoint();
	tx_h_sps = tx_ep->sps;
	rx_h_sps = rx_ep->sps;

	res = sps_get_config(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;
	res = sps_get_config(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect TX = MEM->BAM = Consumer ----\n");
	tx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		tx_connect_options |= SPS_O_POLL;

	tx_connect.source = SPS_DEV_HANDLE_MEM;	/* Memory */
	tx_connect.destination = h;
	tx_connect.mode = SPS_MODE_DEST;	/* Consumer pipe */
	//tx_connect.src_pipe_index = rx_pipe;
	tx_connect.dest_pipe_index = tx_pipe;
	tx_connect.event_thresh = 0x10;
	tx_connect.options = tx_connect_options;

	//tx_desc_fifo.size = 0x100;
	if (option == 93)
		tx_desc_fifo.size = 0x4000;
	else
		tx_desc_fifo.size = 0x400; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &tx_desc_fifo);
	memset(tx_desc_fifo.base, 0x00, tx_desc_fifo.size);
	tx_connect.desc = tx_desc_fifo;

	res = sps_connect(tx_h_sps, &tx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":----Connect RX = BAM->MEM = Producer----\n");
	rx_connect_options =
			SPS_O_AUTO_ENABLE | SPS_O_EOT | SPS_O_ACK_TRANSFERS;
	if (!use_irq)
		rx_connect_options |= SPS_O_POLL;

	rx_connect.source = h;
	rx_connect.destination = SPS_DEV_HANDLE_MEM;	/* Memory */
	rx_connect.mode = SPS_MODE_SRC;	/* Producer pipe */
	rx_connect.src_pipe_index = rx_pipe;
	//rx_connect.dest_pipe_index = tx_pipe;
	rx_connect.event_thresh = 0x10;
	rx_connect.options = rx_connect_options;

	/* rx_desc_fifo.size = 0x100; */
	rx_desc_fifo.size = 0x40; /* Use small fifo to force wrap-around */
	test_alloc_mem(use_pipe_mem, &rx_desc_fifo);
	memset(rx_desc_fifo.base, 0x00, rx_desc_fifo.size);
	rx_connect.desc = rx_desc_fifo;

	res = sps_connect(rx_h_sps, &rx_connect);
	if (res)
		goto exit_err;

	pr_info(DRV_MAME ":-----Allocate Buffers----\n");
	tx_mem.size = tx_size;
	rx_mem.size = rx_size;

	pr_info(DRV_MAME ":Allocating Data Buffers from %s.\n", mem_type);
	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */

		mem = &rx_mem;
		mem->base = kzalloc(mem->size, GFP_KERNEL);
		mem->phys_base = 0xdeadbeef;	/* map later */
	} else {
		test_alloc_mem(use_pipe_mem, &tx_mem);
		test_alloc_mem(use_pipe_mem, &rx_mem);
	}

	pr_info(DRV_MAME ":%s.tx mem phys=%pa.virt=0x%p.\n",
		__func__, &tx_mem.phys_base, tx_mem.base);
	pr_info(DRV_MAME ":%s.rx mem phys=%pa.virt=0x%p.\n",
		__func__, &rx_mem.phys_base, rx_mem.base);

	tx_buf = tx_mem.base;
	rx_buf = rx_mem.base;

	tx_event.mode = SPS_TRIGGER_CALLBACK;
	tx_event.options = SPS_O_EOT;
	tx_event.user = (void *)tx_ep;
	init_completion(&tx_ep->xfer_done);
	tx_event.xfer_done = &tx_ep->xfer_done;
	pr_info(DRV_MAME ":tx_event.event=0x%p.\n", tx_event.xfer_done);

	rx_event.mode = SPS_TRIGGER_CALLBACK;
	rx_event.options = SPS_O_EOT;
	rx_event.user = (void *)rx_ep;
	init_completion(&rx_ep->xfer_done);
	rx_event.xfer_done = &rx_ep->xfer_done;
	pr_info(DRV_MAME ":rx_event.event=0x%p.\n", rx_event.xfer_done);

	/* WARNING: MUST register reg_event to enable interrupt

	   on the pipe level. */
	res = sps_register_event(tx_h_sps, &tx_event);
	if (res)
		goto exit_err;
	res = sps_register_event(rx_h_sps, &rx_event);
	if (res)
		goto exit_err;

	if (loop_test) {
		max_loops = tx_size / 0x40;
		pr_info(DRV_MAME ":----- Start testing for %d loops ----\n", max_loops);
	}

	for (loop = 0; loop < max_loops; loop++) {
		init_completion(&tx_ep->xfer_done);
		init_completion(&rx_ep->xfer_done);

		pr_info(DRV_MAME ":-----Prepare Buffers----\n");

		memset(tx_buf, 0xaa, tx_mem.size);
		memset(rx_buf, 0xbb, rx_mem.size);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
			mem = &rx_mem;
			mem->phys_base = dma_map_single(NULL, mem->base,
							mem->size, 0);
		}

		pr_info(DRV_MAME ":-----Start Transfers----\n");

		tx_xfer_flags =	SPS_IOVEC_FLAG_EOT;
		res = sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, tx_xfer_flags);

		pr_info("sps_transfer_one tx res = %d.\n", res);
		if (res)
			goto exit_err;


		if (option == 93) {
			sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, SPS_IOVEC_FLAG_EOT | SPS_IOVEC_FLAG_EOB | SPS_IOVEC_FLAG_INT);
			sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, SPS_IOVEC_FLAG_EOT | SPS_IOVEC_FLAG_NWD | SPS_IOVEC_FLAG_INT);
			sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, SPS_IOVEC_FLAG_EOT | SPS_IOVEC_FLAG_IMME);
			sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, SPS_IOVEC_FLAG_CMD | SPS_IOVEC_FLAG_LOCK);
			sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, SPS_IOVEC_FLAG_CMD | SPS_IOVEC_FLAG_UNLOCK);
			sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, SPS_IOVEC_FLAG_NWD | SPS_IOVEC_FLAG_CMD);
			for (i = 0; i < 1000; i++)
				sps_transfer_one(tx_h_sps, tx_mem.phys_base, tx_size,
				       tx_h_sps, tx_xfer_flags);
		}

		rx_xfer_flags = 0;
		res = sps_transfer_one(rx_h_sps, rx_mem.phys_base, rx_size,
				       rx_h_sps, rx_xfer_flags);
		pr_info("sps_transfer_one rx res = %d.\n", res);
		if (res)
			goto exit_err;


		pr_info(DRV_MAME ":-----Wait Transfers Complete----\n");

		msleep(10); /* allow transfer to complete */

		/* output register info */
		print_bam_reg(bam);
		print_bam_pipe_reg(bam, tx_pipe);
		print_bam_pipe_reg(bam, rx_pipe);

		/* output desc FIFO content */
		desc = tx_desc_fifo.base;
		pr_info("tx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&tx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);
		desc = rx_desc_fifo.base;
		pr_info("rx desc-fifo at %pa = 0x%lx,0x%lx,0x%lx,0x%lx.\n",
			&rx_desc_fifo.phys_base, desc[0], desc[1], desc[2],
			desc[3]);

		/* wait for interrupt or check if the transfer is complete on RX pipe */
		res = wait_xfer_completion(use_irq, &rx_ep->xfer_done,
					   rx_h_sps, 1, 3, 0);

		if (res) {
			pr_err("sps_test:%s.transfer is not completed.\n",
			       __func__);
			goto exit_err;
		}

		sps_get_iovec(tx_ep->sps, &tx_ep->IOVec);
		sps_get_iovec(rx_ep->sps, &rx_ep->IOVec);

		if (use_cache_mem_data_buf) {
			struct sps_mem_buffer *mem;

			mem = &tx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
			mem = &rx_mem;
			dma_unmap_single(NULL, mem->phys_base, mem->size, 0);
		}

		tx_iovec = tx_ep->IOVec;
		rx_iovec = rx_ep->IOVec;

		pr_info(DRV_MAME ":-----Check Pass/Fail----\n");

		pr_info("sps_get_iovec tx size = %d.\n", tx_iovec.size);
		pr_info("sps_get_iovec rx size = %d.\n", rx_iovec.size);

		pr_info("tx buf[0] = 0x%lx.\n", tx_buf[0]);
		pr_info("rx buf[0] = 0x%lx.\n", rx_buf[0]);
		pr_info("tx buf[tx_size/8-1] = 0x%lx.\n",
			tx_buf[tx_size / 8 - 1]);
		pr_info("rx buf[tx_size/8-1] = 0x%lx.\n",
			rx_buf[tx_size / 8 - 1]);

		/* NOTE: Rx according to Tx size with EOT. */
		if ((tx_iovec.size == tx_size) &&
		    (rx_iovec.size == tx_size) &&
		    (tx_buf[0] == rx_buf[0]) &&
		    (tx_buf[tx_size / 8 - 1] == rx_buf[tx_size / 8 - 1])
		   ) {
			res = 0;
			if (loop_test)
				pr_info("sps:No. %d loop PASS.\n", loop + 1);
		} else {
			res = -1;
			break;
		}

		if (loop_test)
			tx_size -= 0x40;
	}

exit_err:

	pr_info(DRV_MAME ":-----Tear Down----\n");

	pr_info(DRV_MAME ":----- dump BAM registers before clear the data ----\n\n\n");

	sps_get_bam_debug_info(h, option, para, tb_sel, desc_sel);

	pr_info(DRV_MAME ":----- end of dump BAM registers ----\n\n\n\n\n");

	if (use_cache_mem_data_buf) {
		struct sps_mem_buffer *mem;

		mem = &tx_mem;
		kfree(mem->base);
		mem = &rx_mem;
		kfree(mem->base);
	} else {
		test_free_mem(use_pipe_mem, &tx_mem);
		test_free_mem(use_pipe_mem, &rx_mem);
	}
	test_free_mem(use_pipe_mem, &tx_desc_fifo);
	test_free_mem(use_pipe_mem, &rx_desc_fifo);

	sps_disconnect(tx_h_sps);
	sps_disconnect(rx_h_sps);

	deregister_bam(bam, h);

register_err:
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
	if (res == 0)
		pr_info("SPS #%d BAM-DMA SYS-BAM Test %s DESC %s - PASS.\n",
			sps_test_num, irq_mode, mem_type);
	else
		pr_info("SPS #%d BAM-DMA SYS-BAM Test %s DESC %s - FAIL.\n",
			sps_test_num, irq_mode, mem_type);
	pr_info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	return res;
}	/* temp test for register dump API */


/**
 * Write File.
 *
 * @note Trigger the test from user space by:
 * echo 1 > /dev/sps_test
 *
 */

ssize_t sps_test_write(struct file *filp, const char __user *buf,
		       size_t size, loff_t *f_pos)
{
	int ret = 0;

	unsigned long missing;
	static char str[10];
	int i, n = 0;

	memset(str, 0, sizeof(str));
	missing = copy_from_user(str, buf, sizeof(str));
	if (missing)
		return -EFAULT;

	for (i = 0; i < sizeof(str) && (str[i] >= '0') && (str[i] <= '9'); ++i)
		n = (n * 10) + (str[i] - '0');

	sps_test->testcase = n;

	pr_info("\n\n***** sps unit test ***** testcase=%d *****\n\n", (u32) sps_test->testcase);

	sps_test_num = sps_test->testcase;

	//get the virtual address of BAM DMA BAM
	bamdma_virt_addr = ioremap(DMA_PHYS_ADDR, DMA_PHYS_SIZE);
	if (bamdma_virt_addr == NULL) {
		pr_err("sps_test: Unable to map BAM DMA IO memory: 0x%x with size 0x%x",
				DMA_PHYS_ADDR, DMA_PHYS_SIZE);
		return size;
	} else
		pr_info("sps_test: BAM DMA IO memory: phy 0x%x virtual 0x%p",
				DMA_PHYS_ADDR, bamdma_virt_addr);

	switch (sps_test->testcase) {
	case 1:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam(false, false, false, false);
		break;
	case 2:
		/* BAM-to-System, single transfer, IRQ, sys-mem */
		ret = sps_test_sys2bam(true, false, false, false);
		break;
	case 3:
		/* BAM-to-System, single transfer, polling, pipe-mem */
		ret = sps_test_sys2bam(false, true, false, false);
		break;
	case 4:
		/* BAM-to-System, single transfer, IRQ, pipe-mem */
		ret = sps_test_sys2bam(true, true, false, false);
		break;
	case 5:
		/* BAM-to-System, multi-transfer, EOT per Transfer, polling */
		ret = sps_test_multi(false, false, true);
		break;
	case 6:
		/* BAM-to-System, multi-transfer, EOT on last desc only, polling */
		ret = sps_test_multi(false, false, false);
		break;
	case 7:
		/* BAM-to-System, multi-transfer, EOT per Transfer, IRQ */
		ret = sps_test_multi(true, false, true);
		break;
	case 8:
		/* BAM-to-System, multi-transfer, EOT on last desc only, IRQ */
		ret = sps_test_multi(true, false, false);
		break;

	/* sps_transfer */
	case 92:
		ret = sps_test_sps_transfer(false, false);
		break;
	case 93:
		ret = sps_test_sps_transfer(true, false);
		break;

	/* to test debugging features */

	case 101:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 1, 0, 0, 0);
		break;
	case 102:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 2, 0, 0, 0);
		break;
	case 103:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 3, 0, 0, 0);
		break;
	case 104:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 4, 0, 0, 0);
		break;
	case 105:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 5, SPS_BAM_PIPE(4), 0, 0);
		break;
	case 106:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 6, 0, 0, 0);
		break;
	case 107:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 7, 0, 0, 0);
		break;
	case 108:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 8, SPS_BAM_PIPE(5), 0, 0);
		break;
	case 109:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 9, 0, 0, 0);
		break;
	case 110:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 10, 0, 0, 0);
		break;
	case 111:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 11, SPS_BAM_PIPE(4)|SPS_BAM_PIPE(5), 0, 0);
		break;
	case 112:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 12, 0, 0, 0);
		break;
	case 113:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 13, 0, 4, 0);
		break;
	case 114:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 14, SPS_BAM_PIPE(4)|SPS_BAM_PIPE(5), 0, 0);
		break;
	case 115:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 15, SPS_BAM_PIPE(4)|SPS_BAM_PIPE(5), 0, 0);
		break;
	case 116:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 16, SPS_BAM_PIPE(4)|SPS_BAM_PIPE(5), 0, 0);
		break;
	case 191:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 91, 0, 0, 0);
		break;
	case 192:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 92, SPS_BAM_PIPE(4)|SPS_BAM_PIPE(5), 0, 0);
		break;
	case 193:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 93, SPS_BAM_PIPE(4)|SPS_BAM_PIPE(5), 0, 0);
		break;
	case 195:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_sys2bam_with_dump(false, false, false, false, 95, SPS_BAM_PIPE(4)|SPS_BAM_PIPE(5), 0, 0);
		break;

	/* misc testcases */
	/* added for BAM_ERROR_IRQ issue */
	case 501:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_HRESP_ERR_IRQ(false, false, false, false);
		break;

	/* added for PIPE_HRESP_ERROR_IRQ issue */
	case 502:
		/* BAM-to-System, single transfer, polling, sys-mem */
		ret = sps_test_PIPE_HRESP_ERR_IRQ(false, false, false, false);
		break;

	default:
		pr_info(DRV_MAME ":Invalid Test Number.\n");
		break;
	}

	return size;
}

static struct class *sps_test_class;

static const struct file_operations sps_test_fops = {
	.owner = THIS_MODULE,
	.write = sps_test_write,
};

/**
 * Module Init.
 */
static int __init sps_test_init(void)
{
	int ret;

	pr_info(DRV_MAME ":sps_test_init.\n");

	pr_info(DRV_MAME ":SW Version = %s.\n", DRV_VERSION);

	sps_test = kzalloc(sizeof(*sps_test), GFP_KERNEL);
	if (sps_test == NULL) {
		pr_err(DRV_MAME ":kzalloc err.\n");
		return -ENOMEM;
	}
	sps_test->signature = TEST_SIGNATURE;

	sps_test_class = class_create(THIS_MODULE, DRV_MAME);

	ret = alloc_chrdev_region(&sps_test->dev_num, 0, 1, DRV_MAME);
	if (ret) {
		pr_err(DRV_MAME "alloc_chrdev_region err.\n");
		return -ENODEV;
	}

	sps_test->dev = device_create(sps_test_class, NULL, sps_test->dev_num,
				      sps_test, DRV_MAME);
	if (IS_ERR(sps_test->dev)) {
		pr_err(DRV_MAME ":device_create err.\n");
		return -ENODEV;
	}

	sps_test->cdev = cdev_alloc();
	if (sps_test->cdev == NULL) {
		pr_err(DRV_MAME ":cdev_alloc err.\n");
		return -ENODEV;
	}
	cdev_init(sps_test->cdev, &sps_test_fops);
	sps_test->cdev->owner = THIS_MODULE;

	ret = cdev_add(sps_test->cdev, sps_test->dev_num, 1);
	if (ret)
		pr_err(DRV_MAME ":cdev_add err=%d\n", -ret);

	if (ret == 0)
		pr_info(DRV_MAME ":SPS-Test init OK.\n");
	else
		pr_info(DRV_MAME ":SPS-Test init FAIL.\n");

	return ret;
}

/**
 * Module Exit.
 */
static void __exit sps_test_exit(void)
{
	pr_info(DRV_MAME ":sps_test_exit.\n");

	msleep(100); /* allow gracefull exit of the worker thread */

	cdev_del(sps_test->cdev);
	device_destroy(sps_test_class, sps_test->dev_num);
	unregister_chrdev_region(sps_test->dev_num, 1);

	pr_info(DRV_MAME ":sps_test_exit complete.\n");
}

module_init(sps_test_init);
module_exit(sps_test_exit);

MODULE_LICENSE("GPL v2");
MODULE_DESCRIPTION("SPS Unit-Test");



