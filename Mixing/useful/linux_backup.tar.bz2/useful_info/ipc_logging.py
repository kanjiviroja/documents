import struct
import sys
import ctypes


MAGIC = 0x52784425L
NMAGIC = ctypes.c_uint32(~MAGIC).value

def hex_to_str(chars, width, return_string=False):
	output = []
	offset = 0

	while chars:
		line = chars[:width]
		chars = chars[width:]
		strBlankHex = '   ' * (width - len(line))
		strHex = ' '.join("%02x" % ord(c) for c in line) + strBlankHex
		strOut = "%08x %s %s" % (offset, strHex, quotechars(line))
		offset += width

		if return_string:
			output.append(strOut)
		else:
			print strOut

	if return_string:
		return '\n'.join(output) + '\n'

	return None

def quotechars( chars ):
	return ''.join(['.', c][c.isalnum()] for c in chars)

def str_to_hex(strHex):
	return ''.join([chr(int(x.strip(), 16)) for x in strHex.split()])


# Element types
#enum {
#	TSV_TYPE_INVALID,
#	TSV_TYPE_TIMESTAMP,
#	TSV_TYPE_POINTER,
#	TSV_TYPE_INT32,
#	TSV_TYPE_BYTE_ARRAY,
#};
TSV_TYPE_INVALID = 0
TSV_TYPE_TIMESTAMP = 1
TSV_TYPE_POINTER = 2
TSV_TYPE_INT32 = 3
TSV_TYPE_BYTE_ARRAY = 4

# Message types
#enum {
#	TSV_TYPE_MSG_START = 1,
#	TSV_TYPE_SKB = TSV_TYPE_MSG_START,
#	TSV_TYPE_STRING,
#	TSV_TYPE_MSG_END = TSV_TYPE_STRING,
#};
TSV_TYPE_MSG_START = 1
TSV_TYPE_SKB = TSV_TYPE_MSG_START
TSV_TYPE_STRING = 2
TSV_TYPE_MSG_END = 2


# TSV values
#struct tsv_header {
#	unsigned char type;
#	unsigned char size; /* size of data field */
#};
PAGE_HEADER_SIZE = 4*4 + 2*2 + 2*4
PAGE_SIZE = 4*1024
FULL_PAGE_WRITE_OFFSET = 0xFFFF

class LogTSV(object):
	"""Handles processing message/value headers"""

	def __init__(self):
		pass

	def unpack(self, data):
		assert len(data) >= 2
		self.msg_type, self.msg_size = struct.unpack('BB', data[0:2])
		return data[2:]

class TsvTimestamp(object):
	def unpack(self, data):
		tsv = LogTSV()
		data = tsv.unpack(data)
		assert tsv.msg_type == TSV_TYPE_TIMESTAMP
		assert tsv.msg_size == 8

		# read 64-bit timestamp
		timestamp_ns, = struct.unpack('<Q', data[0:8])
		data = data[8:]
		self.fTimestamp =  timestamp_ns * 1.0E-9
		return data

	def __str__(self):
		return '%16.9f' % (self.fTimestamp)

class TsvByteArray(object):
	def unpack(self, data):
		tsv = LogTSV()
		data = tsv.unpack(data)
		assert tsv.msg_type == TSV_TYPE_BYTE_ARRAY

		# read byte array
		self.strByteArray = data[:tsv.msg_size]
		data = data[tsv.msg_size:]
		return data

	def __str__(self):
		return self.strByteArray

class LogMessageString(object):
	def unpack(self, data, tsv):
		# TODO - decode the header again or just the body if
		# the rest of the code decoded the header...
		assert tsv.msg_type == TSV_TYPE_STRING

		# TSV_TYPE_STRING - message type
		# TSV_TYPE_TIMESTAMP
		# TSV_TYPE_BYTE_ARRAY
		self.timestamp = TsvTimestamp()
		data = self.timestamp.unpack(data)

		self.strString = TsvByteArray()
		data = self.strString.unpack(data)

		return data

	def __str__(self):
		return '[%s] %s' % (self.timestamp, self.strString)

class LogPage(object):
	"""A single page in an IPC Logging log"""

	headerBinaryFormat = '<IIIIHH'
	headerBinaryFormatSize = struct.calcsize(headerBinaryFormat)

	def __init__(self):
		self.data = None
		self.previousPage = None
		self.previousData = None
		self.nextPage = None
		self.nextData = None
		self.iterated = False

	@staticmethod
	def SortAndLink(lstPages):
		"""Given a list of pages in ascending page number order,
		sort them chronologically and links the pages together.
		
		This must be called before iterating over items in a page.
		"""
		# sort pages chronologically by finding the first active page
		for n in range(len(lstPages)):
			if lstPages[0].write_offset != FULL_PAGE_WRITE_OFFSET:
				break
			lstPages.append(lstPages.pop(0))
		assert lstPages[0].write_offset != FULL_PAGE_WRITE_OFFSET, \
				"Unable to find starting page"

		# link pages
		numPages = len(lstPages)
		nMaxPage = 0
		for n in range(numPages):
			page = lstPages[n]
			nMaxPage = max(nMaxPage, page.page_num)
			page.previousPage = lstPages[n - 1]
			page.nextPage = lstPages[(n + 1) % numPages]
		assert (nMaxPage + 1) == numPages, \
				"Missing log pages: max page %d, num pages %d" % (nMaxPage, numPages)

		return lstPages

	def unpack(self, data):
		assert len(data) == 4096, len(data)

		self.data = data
		self.magic, self.nmagic, self.log_id, self.page_num, self.read_offset, \
			self.write_offset = \
				struct.unpack(self.headerBinaryFormat, self.data[0:self.headerBinaryFormatSize])

		if self.magic == MAGIC and self.nmagic == NMAGIC:
			return True

		return False


	def __iter__(self):
		"""Message iterator"""
		self.iterated = True

		# handle read data
		self.previousData = None
#		print "Iterating log id %d, page %d" % (self.log_id, self.page_num)
#		print "\tread index:  %x" % (self.read_offset)
#		print "\twrite index: %x" % (self.write_offset)


		# TODO - this can hopefully be simplified once the IPC Logging
		# code has been changed slightly to allow both read from debugfs
		# and crash-dump reading
		if self.read_offset == FULL_PAGE_WRITE_OFFSET \
				and self.write_offset == FULL_PAGE_WRITE_OFFSET:
			# page is either empty or full, but only the page with
			# valid read/write pointers knows if we have data
			self.iter_data = self.data[PAGE_HEADER_SIZE:]
			print "\tfull/empty case"
		elif self.write_offset == FULL_PAGE_WRITE_OFFSET:
			# page is full
			read_iter = self.read_offset + PAGE_HEADER_SIZE
			self.iter_data = self.data[read_iter:]
			print "\tfull case"
		elif self.read_offset == FULL_PAGE_WRITE_OFFSET:
			# page hasn't been read, but has only been partially written
			write_iter = self.write_offset + PAGE_HEADER_SIZE
			self.iter_data = self.data[PAGE_HEADER_SIZE:write_iter]
			print "\tpartial write, no read"
		elif self.read_offset > self.write_offset:
			# almost full buffer
			read_iter = self.read_offset + PAGE_HEADER_SIZE
			write_iter = self.write_offset + PAGE_HEADER_SIZE
			self.iter_data = self.data[read_iter:]
			self.previousData = self.data[PAGE_HEADER_SIZE:write_iter]
			print "\talmost full"
		else:
			# almost empty buffer
			read_iter = self.read_offset + PAGE_HEADER_SIZE
			write_iter = self.write_offset + PAGE_HEADER_SIZE
			self.iter_data = self.data[read_iter:write_iter]
			print "\talmost empty"


		# prepend data from previous page
		if self.previousPage and self.previousPage.nextData:
#			print "Pulling previous data len"
#			hex_to_str(self.previousPage.nextData, 16)
			self.iter_data = self.previousPage.nextData + self.iter_data

#		print "Page data to iterate:\n", hex_to_str(self.iter_data, 16)

		return PageIterator(self)

	def next(self):
		# handles full-buffer condition where write pointer
		# is behind the read pointer
		if self.nextPage and self.nextPage.previousData:
			self.iter_data += self.nextPage.previousData
			self.nextPage.previousData = None

		if len(self.iter_data) < 2:
			# not enough data to retrieve message header
#			print "Pushing data to continue\n%s" % (hex_to_str(self.iter_data, 16))
			self.nextData = self.iter_data
			self.iter_data = None
			raise StopIteration

		tsv = LogTSV()
		data = tsv.unpack(self.iter_data)
		if tsv.msg_size > len(data):
			# not enough data left to extract entire message
#			print "Pushing data to continue\n%s" % (hex_to_str(self.iter_data, 16))
			self.nextData = self.iter_data
			self.iter_data = None
			raise StopIteration

		# TODO - this needs to be replaced with a dictionary for the message
		# deserialization types
		if tsv.msg_type == 0:
			# no more messages
#			print "Message type is 0:\n%s" % (hex_to_str(self.iter_data, 16))
			raise StopIteration
		
		if tsv.msg_type == TSV_TYPE_STRING:
			self.iter_data = data
			msg = LogMessageString()
			self.iter_data = msg.unpack(self.iter_data, tsv)
			return msg
		else:
			assert False, "Unknown message type 0x%x\n%s" % (tsv.msg_type, hex_to_str(self.iter_data, 16))


class PageIterator(object):

	def __init__(self, page):
		self.page = page

	def __iter__(self):
		# TODO - clear all iteration flags
		pass

	def next(self):
		while True:
			try:
				return self.page.next()
			except StopIteration:
				self.page = self.page.nextPage
				if self.page.iterated:
					print "Page %d already iterated" % (self.page.page_num)
					raise
				self.page.__iter__()

if __name__ == '__main__':
	if len(sys.argv) < 2:
		print "Usage: %s file" % (sys.argv[0])
		exit(1)

	# TODO - add feature to parse existing log files
	dictLogs = {}
	if sys.argv[1] == 'test':
		# load existing files
		# TODO -- add full implementation
		strFiles = """\
log-1-0.bin
log-1-1.bin
log-1-2.bin
log-1-3.bin
log-1-4.bin
log-1-5.bin
log-1-6.bin
log-1-7.bin
log-1-8.bin
log-1-9.bin
log-2-0.bin
"""
		lstFiles = strFiles.strip().split()
		for f in lstFiles:
			data = open(f, 'rb').read()
			page = LogPage()
			assert page.unpack(data) == True, "Unable to open file '%s'" % (f)
			if not page.log_id in dictLogs:
				dictLogs[page.log_id] = {}
			dictLogs[page.log_id][page.page_num] = page
			print "Loaded '%s' log id %d, page %d" % (f, page.log_id, page.page_num)
			print "\tread index:  %x" % (page.read_offset)
			print "\twrite index: %x" % (page.write_offset)
	else:
		# scan for new files
		fIn = open(sys.argv[1],'rb')

		print "Parsing '%s'" % (sys.argv[0])
		page = LogPage()
		while True:
			data = fIn.read(PAGE_SIZE)
			if not data or len(data) < PAGE_SIZE:
				break

			if page.unpack(data):
				# found log page
				if not page.log_id in dictLogs:
					dictLogs[page.log_id] = {}
				dictLogs[page.log_id][page.page_num] = page
				print "Found log id %d, page %d" % (page.log_id, page.page_num)
				print "\tread index:  %x" % (page.read_offset)
				print "\twrite index: %x" % (page.write_offset)
				sys.stdout.flush()

				# debug file capture
				fOut = open('log-%d-%d.bin' % (page.log_id, page.page_num), 'wb')
				fOut.write(data)
				fOut.close()
				page = LogPage()
	
		# TODO - cleanup the sync code
		if not len(dictLogs):
			print "Couldn't find any log headers, trying non-4KB page offsets"
			bSeeking = True
			fIn.seek(0)
			data = fIn.read(PAGE_SIZE)
			while True:
				if bSeeking:
					ch = fIn.read(1)
					if not ch:
						break
				else:
					data = fIn.read(PAGE_SIZE)
					if not data or len(data) < PAGE_SIZE:
						break


				data = data[1:] + ch
				if page.unpack(data):
					# found log page
					print "Found log id %d, page %d" % (page.log_id, page.page_num)
					print "\tread index:  %x" % (page.read_offset)
					print "\twrite index: %x" % (page.write_offset)
					sys.stdout.flush()

					if page.log_id > 100:
						# TODO - need better sanity test
						print "invalid log id, skipping"
						sys.stdout.flush()
						page = LogPage()
						continue

					bSeeking = False
					if not page.log_id in dictLogs:
						print "Added %d to logging dict" % (page.log_id)
						dictLogs[page.log_id] = {}
					dictLogs[page.log_id][page.page_num] = page

					# debug file capture
					fOut = open('log-%d-%d.bin' % (page.log_id, page.page_num), 'wb')
					fOut.write(data)
					fOut.close()
					page = LogPage()
		
		fIn.close()



	# dump the logs
	logs = dictLogs.keys()
	logs.sort()
	print "Logs: ", logs
	for key in logs:
		pages = dictLogs[key]
		pageKeys = pages.keys()
		pageKeys.sort()
		print '-'*70
		print "Log id %d (%d pages)" % (key, len(pageKeys))
		print '-'*70

		# sort pages chronologically
		# TODO - should this be done as part of the linking stage?
		lstPages = []
		for n in pageKeys:
			lstPages.append(pages[n])
		lstPages = LogPage.SortAndLink(lstPages)

		# dump data in pages
		try:
			page = lstPages[0]
			for x in page:
				print str(x).strip()
		except:
			pass
		print
