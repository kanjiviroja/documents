#include<stdio.h>
#include<stdlib.h>

struct idt {
	int coeff_a;
	int coeff_b;
};

static struct idt revgf[1] {
	[0x0] = {0x1,0x2},
};
/*
static struct idt revsm[]{
	[0]={0x5, 0x6},
	[1]={0x7, 0x8},
};
*/

/*
static cnt;

void test_app() {
	static int test_var; 

	if (!test_var) {
		test_var = 1;
		cnt = cnt + 1;
	}
	printf("%d\n",cnt);

}

struct test_st {
	int a;
	int b;
	int c; 
	int d;
	unsigned long long e;
};
*/
int main(){
/*
	unsigned int *ptrgf = revgf; 
	unsigned int *ptrsm = revsm;

	printf("ptrgf[0]:a=0x%x, b=0x%x", ptrgf[0].coeff_a, ptrgf[0].coeff_b);
	printf("ptrgf[1]:a=0x%x, b=0x%x", ptrgf[1].coeff_a, ptrgf[1].coeff_b);*/
	
/*	long i;
	unsigned long  j;
	unsigned long k=0;
	long m;
	unsigned int mm = 0xbf;
	unsigned int mk = 0xbf;
	struct test_st *st = NULL;
	int arr[2] = {0x4000000, 0x4000004};
	
	printf("%d:arr[0], %x:&arr[0]\n", arr[0], &arr[0]);

	st = malloc(sizeof(struct test_st));
	if (st == NULL)
		printf("St is null \n");

	i = -110000;	
	j = -110000; 
	k = i;
	m = k; 
//	printf("hello\n");
//	printf("i value =%ld & 0x%lx \n",i,i);
//	printf("j value =%ld & 0x%lx \n",j,j);
//	printf("k value =%ld & 0x%lx \n",k,k);
//	printf("m value =%ld & 0x%lx \n",m,m);

	if (mm > mk)
		printf(" %d is > %d\n", mm, mk);
	else
		printf(" %d is <= %d\n", mm, mk);	

	test_app();
	test_app();
	test_app();

	st->a = 1;
	st->b = 2;
	st->c = 3;
	st->d = 4;
	st->e = 5;

	printf("st.d=%d\n",st->d);

	memset(st, 0xCCCCCCCC, sizeof(struct test_st));


	printf("a=%x, b=%x, c=%x, d=%x, e=%llx\n",
			st->a, st->b, st->c, st->d, st->e);

	free(st);

	if (st == NULL)
		printf("st1 is NULL\n");

	st = NULL; 
	if (st == NULL)
		printf("st2 is NULL\n");
*/


}
