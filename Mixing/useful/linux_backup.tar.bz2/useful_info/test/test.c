#include<stdio.h>

struct test_bit{
	unsigned int var1;
	unsigned int var2:16;
	unsigned int var3:4;
	unsigned int var4:12;
};


struct  sps_iovec {
	unsigned int addr ; 
	union {
		struct {
			unsigned int size:16 ;
			unsigned int flags:16;
		}flags_vsma;

		struct {
			unsigned int size:16 ;
			unsigned int addr_msb:4;
			unsigned int flags:12;
		}flags_lpae;
	}flags;
};

int main(void){

	struct test_bit t_st;
	unsigned int flags = 0x8000 | 0x4000 | 0x2000 | 0x1000; 
	unsigned int lpae_en = 1;
//	flags = flags | 0x800 | 0x400 | 0x200 | 0x100 ; 
//	flags = flags | 0x20 | 0x10 ; 
	t_st.var4 = flags >> 4 ; 
	printf("size %d, flags = %x\n",sizeof(struct test_bit),t_st.var4);

	unsigned long phys_addr = 0x811111111;

	struct sps_iovec iovec;
	iovec.addr = (phys_addr & 0xFFFFFFFF) ; 
	iovec.flags.flags_lpae.size = 0x1000;
	iovec.flags.flags_lpae.flags = 0x8000 >> 4;
	//iovec.flags.flags_lpae.addr_msb = (phys_addr & 0xF00000000ULL) >> 32 ;  
	iovec.flags.flags_lpae.addr_msb = (phys_addr ) >> 32 ; 
	//iovec.flags.flags_lpae.addr_msb = (phys_addr >> 31) & 0xF ; 


	printf("size of struct = %d , size = %x , flags =%x addr_msb = %x\n",
			sizeof(struct sps_iovec),
			iovec.flags.flags_lpae.size,
			iovec.flags.flags_lpae.flags,
			iovec.flags.flags_lpae.addr_msb);

	struct sps_iovec iovect;
	iovect.flags.flags_vsma.flags = 0x8000;
	iovect.flags.flags_vsma.size = 0x1000;

	printf("size of struct = %d , size = %x , flags =%x\n",
			sizeof(struct sps_iovec),
			iovect.flags.flags_vsma.size,
			iovect.flags.flags_vsma.flags);

	printf("LSB address = 0x%x \n",iovec.addr);

	unsigned int *ptr = &iovec ; 
	printf("0x%x \n",*ptr);	
	printf("0x%x \n",*(++ptr));	

	unsigned int yes = lpae_en ? (0x1000&0x000F):0x2000  ;
	
	printf("lpae = %x\n",yes);

	lpae_en = 0;
	yes = lpae_en ? 0x1000:(0x2000+0x20)  ;
	printf("lpae = %x\n",yes);

//	iovec.flags.flags_lpae.addr_msb = 0x8;
	unsigned int eflags = iovec.flags.flags_lpae.flags << 4; 
	unsigned int tflags = iovec.flags.flags_lpae.addr_msb | eflags ; 
	
	printf("%x : %x \n",eflags,tflags);

}

