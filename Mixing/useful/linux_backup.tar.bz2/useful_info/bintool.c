#include <stdio.h>
#include <string.h>
/*program works good except we get an extra word at the end
  like this , 0xFFFF, (shouldn't be there at all)*/
 
FILE *fin, *fout;
 
int main(int argc, char **argv)
{
	 unsigned short val, word_count;
	 //  char buffer[10];
	 char buffer[20];
	     
	 printf ("argv[1]=%s\n", argv[1]);
	       
	 fin = fopen(argv[1], "rb");
	 fout = fopen(argv[2], "wt");
	  
	 word_count = 0;
		      
	 while (!feof(fin)) {
//	        if (word_count == 0) {
//		     fwrite("\t.db\t",1,5,fout);
//	        }
	        val = fgetc(fin);
  //              if (word_count < 15) {
//		      sprintf(buffer, "0x%02X, ", val);
  //  	              word_count++;
//		}
//		else {
		      //sprintf(buffer, "0x%02X\n", val);
		      sprintf(buffer, "%C", val);
//		      word_count = 0;
//		}
		fwrite(buffer, 1, strlen(buffer), fout);
	  }
	  fclose(fin);
	  fclose(fout);
	
	  return (0);
}
