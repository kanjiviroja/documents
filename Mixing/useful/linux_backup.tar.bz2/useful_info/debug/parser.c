#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "sps_debug.h"


// EE = 0 supported only now

#define INITIAL_VERSION 0x1

char *sps_tokens[] = {	"<bam-addr>",
			"<testbus-begin>",
			"<testbus-end>",
			"<bam-begin>",
			"<bam-end>",
			"<pipe-begin>",
			"<pipe-end>",
			"<desc-begin>",
			"<desc-end>"};

char *bamdebug_reg_name[] = {	" BAM_CTRL",
				" BAM_REVISION",
				" BAM_DESC_CNT_TRSHLD",
				" BAM_IRQ_XXXX",  // Not using 
				" BAM_IRQ_YYYY",  // not using 
				" BAM_IRQ_STTS", 
				" BAM_IRQ_CLR",
				" BAM_IRQ_EN",
				" BAM_AHB_MASTER_ERR_CTRLS",
				" BAM_AHB_MASTER_ERR_ADDR",
				" BAM_AHB_MASTER_ERR_DATA",
				" BAM_IRQ_ZZZZ", // not using 
				" BAM_NUM_PIPES",
				" BAM_TIMER",
				" BAM_TIMER_CTRL",
				" BAM_TRUST_REG",
				" BAM_TEST_BUS_SEL",
				" BAM_TEST_BUS_REG",
				" BAM_CNFG_BITS",
				" BAM_SW_REVISION",
				" BAM_IRQ_SRCS_EE",
				" BAM_IRQ_SRCS_MSK_EE",
				" BAM_IRQ_SRCS_UNMASKED_EE"
			};

/*BUG in string parsing , have whitespace @ first character place*/
char *bamdebug_p_reg_name[] = {	" BAM_P_CTRL",
				" BAM_P_RST",
				" BAM_P_HALT",
				" BAM_P_TRUST_REG",
				" BAM_P_IRQ_STTS",
				" BAM_P_IRQ_CLR",
				" BAM_P_IRQ_EN",
				" BAM_P_TIMER",
				" BAM_P_TIMER_CTRL",
				" BAM_P_PRDCR_SDBND",
				" BAM_P_CNSMR_SDBND",
				" BAM_P_EVNT_DEST_ADDR",
				" BAM_P_EVNT_REG",
				" BAM_P_SW_DESC_OFST",
				" BAM_P_DATA_FIFO_ADDR",
				" BAM_P_DESC_FIFO_ADDR",
				" BAM_P_EVNT_GEN_TRSHLD",
				" BAM_P_FIFO_SIZES",
				" BAM_P_RETR_CNTXT",
				" BAM_P_SI_CNTXT",
				" BAM_P_DF_CNTXT",
				" BAM_P_AU_PSM_CNTXT_1",
				" BAM_P_PSM_CNTXT_2",
				" BAM_P_PSM_CNTXT_3",
				" BAM_P_PSM_CNTXT_4",
				" BAM_P_PSM_CNTXT_5",
				" BAM_P_PEER_PIPE"
				};


FILE *fpin,*fpout ;

#define MAX_PIPES 32
//#define DEBUG 0 

#ifdef DEBUG
void dbg(const char *, ...);
#else
static inline void dbg(const char *fmt, ...) {};
#endif 

#ifdef DEBUG
void dbg(const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
}
#endif

static bam_dumpheader *hdr = NULL;
static bamdebug_registers *bam_dbg_regs[2];
static struct bamdebug_p_register *pipe_reg_arr[MAX_PIPES];
static struct testbus_info *tbus[MAX_TESTBUS_SEL];
static struct desc_info *desc_blocks[MAX_PIPES];
static char parse[6][256];
static int sps_token_num = 555;    /* used by parse_bam_strings()*/
static int testbus_count;          /* used to count the testbus reg count*/
static int bam_reg_cnt;
static int parse_buf_token;
static int pipe;
static int desc_pipe;
static int desc_cnt;



void dump_desc_info(void){

	int i,j;
	unsigned int pipenum;
	unsigned int desc_addr;
	unsigned int data_addr;
	unsigned int desc_flags;
	unsigned int descfifo_addr;
	unsigned int descfifo_size;

	for (i=0 ; i < MAX_PIPES ;i++){
		unsigned int *ptr = &(desc_blocks[i]->valid_info);
		int size = sizeof(struct desc_info);
		if (htobe32(*ptr) == 1){
			j = 0;
			pipenum = *(++ptr);
			descfifo_addr = *(++ptr);
			descfifo_size = *(++ptr);
			printf("\nPIPE %d descriptor information Desc_FIFO_Addr=0x%x:Desc_FIFO_Size=0x%x\n",
					htobe32(pipenum),htobe32(descfifo_addr),htobe32(descfifo_size));
			desc_addr = htobe32(*(++ptr));
			printf("[desc_addr]= \
						data_addr: \
						desc_flags \n");
			while (desc_addr){
				data_addr = htobe32(*(++ptr));
				desc_flags = htobe32(*(++ptr));
				printf("[0x%8x]= \
						0x%8x: \
						0x%8x \n",
						desc_addr,
						data_addr,
						desc_flags);
				desc_addr = htobe32(*(++ptr));
			}
		}
	}
}



void dump_testbus_information(void){
	int i;
	printf("\nTestbus register information\n");
	for(i=0;i<testbus_count;i++){
		printf("testbus_sel=0x%x testbus_reg=0x%x\n",htobe32(tbus[i]->sel),htobe32(tbus[i]->reg));
	}
}

void dump_bamdebug_p_registers(void){

	int i,j;

	for (i=0 ; i < MAX_PIPES ;i++){
		unsigned int *ptr = &(pipe_reg_arr[i]->bam_p_dumptype);
		int size = sizeof(struct bamdebug_p_register);
		if (htobe32(*ptr) == 1){
			j = 0;
			printf("\nPIPE[%d] information\n",i);
			while (size){
				printf("[%d] = 0x%x\n",j++,htobe32(*ptr));	
				ptr++;
				size -= 4;
			}
		}
	}
}

void dump_bam_debug_registers(void){
	
	int i;
	int size;
	printf("\nBAM register count %d\n",bam_reg_cnt);

	for (i = 0; i < bam_reg_cnt ; i++){
		unsigned int *ptr = &bam_dbg_regs[i]->bam_dumptype;
		printf("\nBAM register information for bam = %d\n",i);
		int j=0;
		size = sizeof(bamdebug_registers);
		while (size){
			printf("[%d]=0x%x\n",j++,htobe32(*ptr));
			ptr++;
			size = size - 4; 
		}
	}
}

void dump_header_structure(void){

	int size = sizeof(bam_dumpheader)/4;
	unsigned int *ptr = &hdr->revision;


	printf("\n---BAM Header information ----\n");
	int i = 0;
	while(size--){
		printf("[%d]=0x%x\n",i++,htobe32(*ptr));
		ptr++;
	}

}

int write_to_bam_structures(char *buf,enum base_for_conv base){
	char *endptr;
	unsigned long val; 

	if (strstr(buf,"0x") && (base == hex) )
		val = strtoul(buf,&endptr,16);
	else
		val = strtoul(buf,&endptr,10);

	return val;
}


void cpy_pipe_registers(int pipe_index){

	int i;
	unsigned int *ptr;
	unsigned int *ptrpipe = &pipe_reg_arr[pipe_index]->bam_p_ctrln;
	
	for (i = 0;i < (sizeof(bamdebug_p_reg_name)/sizeof(bamdebug_p_reg_name[0]));i++){
		if (strncmp(parse[0],bamdebug_p_reg_name[i],strlen(parse[0]))== 0){
			ptrpipe = ptrpipe + i;
			//*ptrpipe = write_to_bam_structures(parse[1],hex);
			*ptrpipe = htobe32(write_to_bam_structures(parse[1],hex));
			break;
		}
	}
}

void cpy_bam_registers(void){
	
	// we have two buffers
	// parse[0] == names 
	// parse[1] == values 
	int i;
	unsigned int *ptr = &bam_dbg_regs[bam_reg_cnt]->bam_ctrl;

	for (i = 0;i < (sizeof(bamdebug_reg_name)/sizeof(bamdebug_reg_name[0]));i++){
		if (strncmp(parse[0],bamdebug_reg_name[i],strlen(parse[0])) == 0){
			ptr = ptr + i ; 
			if (strstr(parse[1],"0x"))
				//*ptr = write_to_bam_structures(parse[1],hex);
				*ptr = htobe32(write_to_bam_structures(parse[1],hex));
			else
				//*ptr = write_to_bam_structures(parse[1],dec);
				*ptr = htobe32(write_to_bam_structures(parse[1],dec));
					
			break;
		}
	}

}
int parse_strings(char *buf,char *str,int opt){

	int rc = -1;
	if (opt == 0) {
		char tmp[256];
		int orglen,len;
		if (buf == NULL)
			return rc;
		strcpy(tmp,buf);
		orglen = strlen(buf);
		if (strtok(buf,str) != NULL){
			len = strlen(buf);
			strcpy(buf,&tmp[len+1]);
		//	buf[orglen-(len+2)] = '\0';
			rc = 0; 
		}
	}
	else {
		char *value; 
		int i = 0; 
		if (parse_buf_token == 0)
			memset(parse,0,sizeof(parse));	
		value = strtok(buf,str);
		while (value != NULL){
	//		printf("i =%d value =%s\n",i,value);
			memset(parse[parse_buf_token],'0',256);
			strcpy(parse[parse_buf_token],value);
			parse_buf_token++;	
			value = strtok(NULL,str);
		}
		rc = 0;		
	}
	return rc;
}

int parse_bam_data_info(char *buf){

	int rc = 0;
	parse_buf_token = 0; 	

	if (sps_token_num == 1){
		int i; 
		int j;
		int init_token = parse_buf_token;
		int last_token = 0;
		char testbus_reg[12];
		int selection_val = 555;
		parse_strings(buf,":",0); // removing "sps:" information
		parse_strings(buf," ",1); // parsing testbus register and selection	
		// parse[0] = testbus register
		// parse[1] = testbus selection


		if (strncmp(parse[1],"TEST_BUS_SEL",12) == 0){
			parse_strings(parse[1],":",1);	
			// parse[2] = selection string
			// parse[3] = selection value

			if (strstr(parse[3],"0x"))
				selection_val = write_to_bam_structures(parse[3],hex);
		}
		
		if (strncmp(parse[0],"TEST_BUS_REG",12) == 0){

			parse_strings(parse[0],":",1);
			//parse[4] = register strings
			//parse[5] = register value
			if (strstr(parse[5],"0x")){
				if (selection_val != 555)
					tbus[testbus_count]->sel = htobe32(selection_val);
					tbus[testbus_count]->reg = htobe32(write_to_bam_structures(parse[5],hex));
					testbus_count++;
			}
		}

	}
	else if (sps_token_num == 3){
		parse_strings(buf,":",1);
		// parse[0] = bam register string
		// parse[1] = bam register value
		if (parse_buf_token == 2){
			cpy_bam_registers();
		}
	}
	else if (sps_token_num == 5){
		parse_strings(buf,":",1);
		//parse[0] = pipe register string
		//parse[1] = pipe register value
		if (parse_buf_token == 2){
			cpy_pipe_registers(pipe);
		}

	}
	else if (sps_token_num == 7){
			
		parse_strings(buf,":,",1);
		//parse[0] = desc_fifo_addr||parse[1] = desc_fifo_size
		//parse[0] = desc_addr     ||parse[1] = desc_data_addr || parse[2] = desc_flags
		//printf("buffers=%s:%s:%s\n",parse[0],parse[1],parse[2]);
		
		desc_blocks[desc_pipe]->pipe_num = htobe32(desc_pipe);
		desc_blocks[desc_pipe]->valid_info = htobe32(1);

		if ((strncmp(parse[0]," BAM_P_DESC_FIFO_ADDR",20) == 0) &&
							(parse_buf_token == 2)){
			dbg("Desc_Fifo_addr=0x%x\n",write_to_bam_structures(parse[1],hex));	
			desc_blocks[desc_pipe]->desc_fifo_addr = htobe32(write_to_bam_structures(parse[1],hex));
			
		}
		else if ((strncmp(parse[0]," BAM_P_DESC_FIFO_SIZE",20) == 0) &&
							(parse_buf_token == 2)){
			//To apart hex and decimal values
			if (strstr(parse[1],"(")){
				parse_strings(parse[1]," ",1);
				if (strstr(parse[2],"0x")){
					dbg("Desc Fifo size =0x%x\n",write_to_bam_structures(parse[2],hex));
					desc_blocks[desc_pipe]->desc_fifo_size = htobe32(write_to_bam_structures(parse[2],hex));
				}
			}
		}
		else{
			if (parse_buf_token >= 3){
				dbg("Desc_Addr=0x%x:Desc_content=0x%x:Desc_flags=0x%x\n",
						write_to_bam_structures(parse[0],hex),
						write_to_bam_structures(parse[1],hex),
						write_to_bam_structures(parse[2],hex));
				desc_blocks[desc_pipe]->desc_iovec[desc_cnt].desc_addr = htobe32(write_to_bam_structures(parse[0],hex));
				desc_blocks[desc_pipe]->desc_iovec[desc_cnt].desc_data_addr = htobe32(write_to_bam_structures(parse[1],hex));
				desc_blocks[desc_pipe]->desc_iovec[desc_cnt].desc_flags = htobe32(write_to_bam_structures(parse[2],hex));
				desc_cnt++;
			}
		}
	}
	else {
		printf("wrong info @ %s\n",__func__);
		rc = -1;
	}
	return rc ;
}



int parse_sps_tokens(char *buf){
	int i;
	int rc = 0;

	for (i = 0;i < (sizeof(sps_tokens)/sizeof(sps_tokens[0]));i++){
		if (strstr(buf,sps_tokens[i])){
			sps_token_num = i;
			break;
		}	
	}

		
		switch(sps_token_num){

		case 0:
			if (strstr(buf,"BAM")){
				char *value; 
				value = strtok(buf,":.");
				while (value != NULL){
					if (strstr(value,"0x")){
						//printf("BAM phy addr = 0x%x\n",write_to_bam_structures(value,hex));
						bam_dbg_regs[bam_reg_cnt]->bam_base_pa = htobe32(write_to_bam_structures(value,hex));
						bam_dbg_regs[bam_reg_cnt]->bam_dumptype = htobe32(0x1); 
						bam_reg_cnt++;
					}				
					value = strtok(NULL,":.");
				}	
			}
			break;
		case 1:
			if (strstr(buf,"TEST_BUS")){
			}
			break;
		case 2:
			if (strstr(buf,"TEST_BUS")){
			}
			break;
		case 3:
			if (strstr(buf,"BAM-level")){
			}
			break;
		case 4:

			if (strstr(buf,"BAM-level")){
			}
			break;
		case 5:
			if ((buf[0] >= '0') && (buf[0] <= '9')){
				dbg("pipe %s & %d\n",buf,atoi(buf));
					pipe = write_to_bam_structures(buf,hex);
					if ((pipe < 32) && (pipe >= 0)){
						pipe_reg_arr[pipe]->bam_p_index = htobe32(pipe); 
						pipe_reg_arr[pipe]->bam_p_dumptype = htobe32(0x1); 
						hdr->pipemask = (htobe32(hdr->pipemask) |(1 << pipe));
						hdr->pipemask = htobe32(hdr->pipemask);
					}
					else{
						printf("PIPE number is not valid\n");
					/*Temp unknown pipe set to zeroth pipe */
						pipe = 0;
						rc = -1;
					}
					 	
			}
			break;
		case 6:
			if ((buf[0] >= '0') && (buf[0] <= '9')){

			}
			break;
		case 7:
			/*Need to implement the part for descriptroe saving*/
			if ((buf[0] >= '0') && (buf[0] <= '9')){
					int local_pipe = 555; 
					desc_cnt = 0;
					local_pipe = write_to_bam_structures(buf,hex);
					if ( htobe32(hdr->pipemask) & (1 << local_pipe)){
						//dbg("Descriptor for active pipes\n");
						desc_pipe = local_pipe; 
					}
					else{
						printf("Descriptor for nonactive pipe %d\n",local_pipe);
						desc_pipe = 555; 
					}
			}
			break;
		case 8:
			if ((buf[0] >= '0') && (buf[0] <= '9')){
			}
			break;
		default:
			printf("Invalid value of sps_token=%d\n",sps_token_num);
		//	rc = -1;
		}
	return rc;	
}


int parse_bamstrings(char* buf){

	int rc = 0;
	if (buf == NULL)
		return -1; 

	if (strncmp(buf," sps:<",6) == 0){
		
		char *token;
		//char tmp[256] ;
		//strcpy(tmp,buf);

		token = strtok (buf," ");

		while (token != NULL){
			rc = parse_sps_tokens(token);
			if (rc){
				printf("SPS token parsing failed\n");
				break;
			}
			else
				token = strtok (NULL," ");
		}
	}
	else{
		int valid_flag = 0; 
		if ((sps_token_num == 1) && ((strstr(buf,"TEST_BUS_REG")) && 
					(strstr(buf,"TEST_BUS_SEL")))){
			valid_flag = 1;
		}		
		else if ((sps_token_num == 3) && (!strncmp(buf," BAM_",5))){
			valid_flag = 1;
		}
		else if ((sps_token_num == 5) && (!strncmp(buf," BAM_P",6))){
			valid_flag = 1;
		}
		else if ((sps_token_num == 7)){ 
			valid_flag = 1;
		}
		else{
			valid_flag = 0;
			//Unusable strings 
		}

		if (valid_flag == 1){
		//	dbg("%s\n",buf);
			rc = parse_bam_data_info(buf);
			if (rc){
				printf("failec to parse bam data\n");
			}
		}
	}	
	return rc; 
}


int manipulate_strings(FILE *fptr){
	int rc = 0;
	char line[256] = {0};
	
	while(!feof(fptr)){
		bzero(line,256);
		if (fgets(line,256,fptr) != NULL){
			
			dbg("length=%d,pos=%ld,string=%s\n",(int) strlen(line),ftell(fptr),line);
			rc = parse_strings(line,"]",0);
			if ((rc < 0) || (line == '\0'))
				break; /*Error in timestamp parsing*/
			
			if ((line[0] != '\n') && (line[0] != '\0')){
				rc = parse_bamstrings(line);
				if (rc){
					printf("Failed BAM strings parsing\n");
				}
			}
		//	else if (line[0] == '\n')
		//		printf("NEWLINE \n");
		//	else
		//		printf("NULL LINE\n");	
		}
		 	
	}
	return rc; 
}

void dump_data(void){

	dump_header_structure();
	dump_bam_debug_registers();
	dump_bamdebug_p_registers();
	dump_testbus_information();
	dump_desc_info();

}


void add_buffer(void){

	char buffer[32];
	unsigned long int tell = ftell(fpout);
	unsigned int offset1 = tell%0x20;
	if (offset1){
		unsigned int offset2 = (tell - offset1)+ 0x20;
		tell = offset2 - tell; 
		memset(buffer,'$',tell);
		buffer[tell] = '\0';
		fwrite(buffer,1,strlen(buffer),fpout);
	}

}

int write_to_file(void){

	int i;
	int rc=0;
	fpout = fopen("dump.bin","wb");

	char buffer[32];
	// HEADER 
	snprintf(buffer,33,"%s","BAM_REG_DUMP_HDDR_XXXXXXXXXXXXXXX");
	fwrite(buffer,1,strlen(buffer),fpout);
	fwrite(hdr,sizeof(bam_dumpheader),1,fpout);
	
	//printf("after hddr=0x%lx\n",ftell(fpout));
	add_buffer();
	//BAM registers	
	snprintf(buffer,33,"%s","BAM_REG_DUMP_XXXX_XXXXXXXXXXXXXXX");
	fwrite(buffer,1,strlen(buffer),fpout);
	fwrite(bam_dbg_regs[0],sizeof(bamdebug_registers),1,fpout);

	add_buffer();
	//BAM PIPE registers
	for (i = 0 ; i < MAX_PIPES ; i++) {

		unsigned int *ptr = &(pipe_reg_arr[i]->bam_p_dumptype);
		if (htobe32(*ptr) == 1){
			sprintf(buffer,"%s","BAM_PIPE_");
			sprintf(buffer+strlen(buffer),"0x%.4x",i);
			sprintf(buffer+strlen(buffer),"%s","_REG_DUMPXXXXXXXX");
			fwrite(buffer,1,strlen(buffer),fpout);
			fwrite(pipe_reg_arr[i],sizeof(bamdebug_registers),1,fpout);
			add_buffer();
		}	
	}

	//BAM TestBus registers	
	for (i = 0;i < testbus_count ; i++){
		memset(buffer,0,32);
		sprintf(buffer,"%s","BAM_TEST_BUS_DUMP_SEL_REG_XXXXXX");
		fwrite(buffer,1,strlen(buffer),fpout);
		fwrite(tbus[i],sizeof(struct testbus_info),1,fpout);
		add_buffer();
	}

	//BAM Descriptor information
	for (i = 0 ; i < MAX_PIPES ; i++) {

		memset(buffer,0,32);
		unsigned int *ptr = &(desc_blocks[i]->valid_info);
		if (htobe32(*ptr) == 1){
			sprintf(buffer,"%s","BAM_PIPE_");
			sprintf(buffer+strlen(buffer),"0x%.4x",i);
			sprintf(buffer+strlen(buffer),"%s","_DESC_DUMPXXXXXXX");
			fwrite(buffer,1,strlen(buffer),fpout);
			fwrite(desc_blocks[i],sizeof(struct desc_info),1,fpout);
			add_buffer();
		}	
	}

	
	fclose(fpout);

	return rc;
}

int parse_file(void){
	
	int rc =0 ;

	fpin = fopen("dump.txt","r");
	if (fpin == NULL) 
		return -1;

	rc = manipulate_strings(fpin);
	if (rc)
		printf("failed to get the correct string values\n");	

	fclose(fpin);

	return rc;
}


int  allocate_memory(void){

	int i;

	hdr = (bam_dumpheader*)malloc(sizeof(bam_dumpheader));	
	if (hdr == NULL)
		goto alloc_fail;

	for (i = 0 ; i < 2 ; i++){
		bam_dbg_regs[i] = (bamdebug_registers*)malloc(sizeof(bamdebug_registers));
		if (bam_dbg_regs[i] == NULL)
			goto alloc_fail;
		memset(bam_dbg_regs[i],0,sizeof(bamdebug_registers));
	}

	//struct bamdebug_p_register  *pipe_reg_arr = (struct bamdebug_p_register*)malloc(sizeof(struct bamdebug_p_register)*MAX_PIPES);
	//need to use dereference as (.)dot 
	for (i = 0 ; i < MAX_PIPES ; i++) {
		pipe_reg_arr[i] = (struct bamdebug_p_register*) malloc(sizeof(struct bamdebug_p_register));
		if (pipe_reg_arr[i] == NULL)
			goto alloc_fail;
		memset(pipe_reg_arr[i],0,sizeof(struct bamdebug_p_register));
	}

	for (i = 0 ; i < MAX_PIPES ; i++) {
		desc_blocks[i] = (struct desc_info*) malloc(sizeof(struct desc_info));
		if (desc_blocks[i] == NULL)
			goto alloc_fail;
		memset(desc_blocks[i],0,sizeof(struct desc_info));
	}

	for (i = 0 ; i < MAX_TESTBUS_SEL ; i++) {
		tbus[i] = (struct testbus_info*)malloc(sizeof(struct testbus_info));
		if (tbus[i] == NULL)
			goto alloc_fail;
	}	

	return 0;

alloc_fail:
	printf("Error in allocation\n");
	return -1;

}


int main(void)
{
	int rc = 0;
	unsigned int k = 1;
	char *c = (char*)&k;

	if (*c)
		printf("LE\n");
	else
		printf("BE\n");

	//Allocation memory for all structures
	rc = allocate_memory();

	// Parsing dump.txt file 
	rc = parse_file();

	// Revision
	// 8:0   --> Minor Rev changes as per SW
	// 15:8  --> Major Rev
	// 23:16 --> Initial Version
	// 31:24 --> reserved
	hdr->revision = htobe32((INITIAL_VERSION << 16)); 

	//Dumping of register details/
	dump_data();

	// Writing to dump.bin file 
	rc = write_to_file();
	
	return rc;

}
