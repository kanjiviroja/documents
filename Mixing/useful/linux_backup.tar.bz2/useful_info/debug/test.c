#include<stdio.h>

struct tch{
	char a;
	char b;
	char c;
	char d;
};


int recur(int val)
{
	printf("val=%d: ", val);
	return (val * recur(val-1));
}

int main(void){

	int s = 0;
	int a ; 
	int ab = 6;
	int ac = 4;
	float ad;
	short arr[4][3] = {{1}, (2,3), (4,5,6)};
	int aptr = 10;
	int *ptr1 = &aptr;
	int **ptr2 = &ptr1;
	int ***ptr3 = &ptr2;
	char str[25] = "qualcomm";
	char name[25];
	struct tch chk = { 0x10, 0x11, 0x12, 0x13};
	int *ptr = (int*)&chk;
	int aa = 5; 
	int ba = 15;
	int abc[0];
	
	printf("chk = %p\n", (void*)&chk);
	printf("trchka = 0x%x ptr=%p\n", chk.a, &(chk.a));
	printf("trchkb = 0x%x ptr=%p\n", chk.b, &(chk.b));
	printf("trchkc = 0x%x ptr=%p\n", chk.c, &(chk.c));
	printf("trchkd = 0x%x ptr=%p\n", chk.d, &(chk.d));
	printf("trchk = 0x%x ptr=%p \n", *ptr, ptr);
	
	printf("myvalues %d %2d %d %2d \n", ba, ba, aa, aa);



	snprintf(name, sizeof(name), str);
	printf("name=%s\n", name);
	printf("aptr=%d:*ptr1=%d:**ptr2=%d:***ptr3=%d\n",
			aptr, *ptr1, *(*ptr2), *(*(*ptr3)));	


//	printf("s=%d:\n", s);
//	a = s/1000;
//	printf("a=%d\n", a);
//	s = 1/a;


	ad = ab/ac;
	ad = (1/2.0) + (1/2);
	printf("ad=%.2f & ad=%f ad=%2f\n", ad, ad, ad);

	printf("0xf & ~0x9 = %x\n", (0xf & (~0x9)));	

	printf("sizeofarray=%ld\n", sizeof(arr));

	for(a=0 ; a<5 ; a++)
		switch(a)
		{
			case 2: printf("case2=%d\n", a);
			case 0: printf("case0=%d\n", a);
			default:
			       printf("default=%d\n",a);
			       break;
			case 4:printf("case4=%d\n", a);
		}

	ab = 0;
	for(a=0 ; a<5 ; a++) {

		ab++;
		if (ab == 3) {
			printf("ab=%d cont@%d\n", ab, a);
			continue;
		}
		if (ab > 3) {
			printf("ab=%d break@%d\n", ab, a);
			break;
		}
		++ab;
		printf("ab=%d @%d\n", ab, a);
	}

	a = 0;
	ab = 6;
	ac = -14;

	a = ac + ab++;
	printf("a=%d, ab=%d\n", ++a, ab++);

	char xx = 0;
//	scanf("%c", &xx);
//	printf("xx=%d\n", xx);
	while(1) {
		if (xx == 'b') {
			printf("exiting code\n");
			break;	
		} else {
			printf("Enter value 1-5 or 'b' for break\n");
			scanf("%c", &xx);
			printf("xx=%c\n", xx);
		}

		switch(xx) {

			case '1':
				printf("axx=%c\n", xx);
				break;
			case '2':
				printf("bxx=%c\n", xx);
				break;
			case '3':
				printf("cxx=%c\n", xx);
			case '4':
				printf("dxx=%c\n", xx);
				break;
			case '5':
				printf("exx=%c\n", xx);
			case '6':
				printf("fxx=%c\n", xx);
				break;
			case '7':
				printf("gxx=%c\n", xx);
				break;
			default:
				printf("xx=%c\n", xx);
				break;
		}

	
	}

//	recur(5);

}
