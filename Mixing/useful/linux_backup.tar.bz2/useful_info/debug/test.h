extern enum typebam bamtype;
enum typebam get_bam_type(void);

enum typebam {
	T_BAM,
	M_BAM,
};
