#include<stdio.h>
#include"test.h"

enum typebam bam_of_type;

void pr_test(void) {
	printf("%s:\n", __func__);
	bam_of_type = get_bam_type();
	printf("1bam_type=%d", bam_of_type);
}
