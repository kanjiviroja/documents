#include<stdio.h>

struct tlist{
	int a_k;
	int b_k;
};

static struct tlist lst = {
	.a_k = 1,
	.b_k = 2,
};

static struct tlist lstarr[] = {
	[0] = {3,4},
	[1] = {5,6},
};

static struct tlist lstarrd[][2] = {
	/* chip id1  */
	{ /* ID1 & ID2 */
	[0] = {3,4},
	[1] = {5,6},
	},
	{ /* chip id2 */
	[0] = {7,8},
	[1] = {9,0xa},
	},
};

int main()
{
	struct tlist *tl1= &lstarrd[0][0];
//	printf("lstattd_0_0=0x%x, %p\n", &lstarrd[0][0], &lstarrd[0][0]);
//	printf("lstattd_0_1=0x%x, %p\n", &lstarrd[0][1], &lstarrd[0][1]);
//	printf("lstattd_1_0=0x%x, %p\n", &lstarrd[1][0], &lstarrd[1][0]);
//	printf("lstattd_1_1=0x%x, %p\n", &lstarrd[1][1], &lstarrd[1][1]);
	printf("tlst:a=%d, b=%d\n", lst.a_k, lst.b_k);
	printf("tlsta1:a=%d, b=%d\n", lstarr[0].a_k, lstarr[0].b_k);
	printf("tlsta2:a=%d, b=%d\n", lstarr[1].a_k, lstarr[1].b_k);
	printf("tlst1->0:a=%d, b=%d\n", (tl1)->a_k, (tl1)->b_k);
	printf("tlst1->1:a=%d, b=%d\n", lstarrd[0][1].a_k, lstarrd[0][1].b_k);
	printf("tlst2->0:a=%d, b=%d\n", lstarrd[1][0].a_k, lstarrd[1][0].b_k);
	printf("tlst2->1:a=%d, b=%d\n", lstarrd[1][1].a_k, lstarrd[1][1].b_k);
}
