#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sps_debug.h"

FILE *fin, *fout;

static bam_dumpheader *hdr = NULL;
static endian_flag = 0;

void byte_swap(unsigned int *number){
	printf("number =%x\n",*number);
	if (!endian_flag)
		*number = ((*number & 0x000000FF) << 24) | ((*number & 0x0000FF00) << 8 ) | ((*number & 0x00FF0000) >>8) | ((*number & 0xFF000000)>>24) ;
}


static char *bam_dumpheader_strings[6]={"BAM_DUMPHDDR_REVISIONxxxxxxx",
					"BAM_DUMPHDDR_PMASK_CPxxxxxxx",
					"BAM_DUMPHDDR_PMASK_PPxxxxxxx",
					"BAM_DUMPHDDR_HDR_SIZExxxxxxx",
					"BAM_DUMPHDDR_BAM_BUFSxxxxxxx",
					"BAM_DUMPHDDR_PIP_BUFSxxxxxxx" };

int main(void)
{

	unsigned short val, word_count,count;
	unsigned int ch;
	char buffer[32];
	unsigned int i = 1;
	char *c = (char*)&i;

	/*bam_dumpheader hddr={0x00010102,0x3F,0x0,0x18,0x02B4,0x88};*/
	bam_dumpheader hddr={0x12345678,0x3F,0x0,0x18,0x02B4,0x8808};
	/*hdr = (bam_dumpheader*)malloc(sizeof(bam_dumpheader));*/
	hdr = &hddr;

	if (*c){
		printf("Code is running on Little endian arch\n");
	}
	else{
		endian_flag = 1;
	   	printf("Code is running on Big endian arch\n");
	}

	printf("bintool: revision = %x \n",hdr->revision);
	printf("bintool: pipemask = %x \n",hdr->pipemask);
	printf("bintool: peerpipemask = %x \n",hdr->peerpipemask);
	printf("bintool: dump_header_size = %x \n",hdr->dump_header_size);
	printf("bintool: bam_buf_size = %x \n",hdr->bam_buf_size);
	printf("bintool: pipe_buf_size = %x \n",hdr->pipe_buf_size);

	unsigned int *ptr = &hdr->revision;

	fout = fopen("test.bin", "wb");

	//printf("ptr = %p \n", ptr);
	//ptr++;
	//printf("ptr = %x \n", *ptr);


	word_count = sizeof(bam_dumpheader);
	if (word_count){
		int i=0;
		//printf("sizeof bam_dumpheader %d\n",word_count);
		while(word_count){
			//printf("ptr = %p \n", ptr);
			//printf("ptr = %x \n", *ptr);
			byte_swap(ptr);
			//printf("modified ptr = %x \n", *ptr);
			snprintf(buffer,32,"%s",bam_dumpheader_strings[i++]);
			//printf("buflength %d\n",strlen(buffer));
			//sprintf(buffer,"%s","Dipen");
			fwrite(buffer,1,strlen(buffer),fout);
			fwrite(ptr,sizeof(unsigned int),1,fout);
			ptr++;
			word_count=word_count-4;
		}
	}

	printf("bintool: revision = %x \n",hdr->revision);
	printf("bintool: pipemask = %x \n",hdr->pipemask);
	printf("bintool: peerpipemask = %x \n",hdr->peerpipemask);
	printf("bintool: dump_header_size = %x \n",hdr->dump_header_size);
	printf("bintool: bam_buf_size = %x \n",hdr->bam_buf_size);
	printf("bintool: pipe_buf_size = %x \n",hdr->pipe_buf_size);



	//ch = 0x12345678;
	//byte_swap(&ch);

	//printf("ch =%x\n",ch);

	//fwrite(&ch,sizeof(unsigned int),1,fout);
	//fwrite(&hddr,sizeof(bam_dumpheader),1,fout);
	fclose(fout);


	fin = fopen("test.bin","rb");
	while(!feof(fin)){
		printf("%x",fgetc(fin));
	}
	fclose(fin);


	printf("bintool loaded successfully\n");
	return 0;
}
