/*
 * Header File for Coredump Binary tool
 *
 *
 *
 *
 */
#define BAM_EE_MAX 8
#define MAX_DESC_NUM 256
#define MAX_TESTBUS_SEL 80

typedef unsigned int uint32;


enum base_for_conv {
	dec,
	hex,
};


typedef struct
{
	uint32 revision;
	uint32 pipemask;
	uint32 peerpipemask;					   /* Right now no option to know BAM2BAM or BAM2SYS mode - may be we have to add in linux driver dump */
	uint32 dump_header_size;                   /* What to fill here */
	uint32 bam_buf_size;					   /* What to fill here */
	uint32 pipe_buf_size;					   /* What to fill here */
}bam_dumpheader;


typedef struct
{
	uint32 bam_dumptype;                         /* What is the bamdumptype */
	uint32 bam_base_pa;                          /* BAM Physical base address   */
	uint32 bam_ctrl;
	uint32 bam_revision;
	uint32 bam_desc_cnt_trshld;
	uint32 bam_irq_srcs;                          /* Right now it's not getting from dmesg */
	uint32 bam_irq_srcs_mask;					  /* Right now it's not getting from dmesg */
	uint32 bam_irq_stts;
	uint32 bam_irq_clr;
	uint32 bam_irq_en;
	uint32 bam_ahb_master_err_ctrls;
	uint32 bam_ahb_master_err_addr;
	uint32 bam_ahb_master_err_data;
	uint32 bam_irq_srcs_unmasked;				  /* Right now it's not getting from dmesg */
	uint32 bam_num_pipes;
	uint32 bam_timer;
	uint32 bam_timer_ctrl;
	uint32 bam_trust_reg;
	uint32 bam_test_bus_sel;
	uint32 bam_test_bus_reg;
	uint32 bam_cnfg_bits;
	uint32 bam_sw_version;
	/*uint32 bam_irq_srcs_een[BAM_EE_MAX];*/
	uint32 bam_irq_srcs_een;        			/* Single EE=0 Supported  */
	/*uint32 bam_irq_srcs_msk_een[BAM_EE_MAX];*/
	uint32 bam_irq_srcs_msk_een;   				/* Single EE=0 Supported  */
	/*uint32 bam_irq_srcs_unmasked_een[BAM_EE_MAX];*/
	uint32 bam_irq_srcs_unmasked_een;			/* Single EE=0 Supported  */
}bamdebug_registers;


struct bamdebug_p_register
{
	uint32 bam_p_dumptype;
	//bamdebug_registers *bam_ptr;				/* Removed as we are copying from dmesg, we don't have any pointer */
	uint32 bam_base_pa;  						/* added for detecting BAM  not used currently*/
	uint32 bam_p_index;
	uint32 bam_p_ctrln;
	uint32 bam_p_rstn;
	uint32 bam_p_haltn;
	uint32 bam_p_trust_regn;
	uint32 bam_p_irq_sttsn;
	uint32 bam_p_irq_clrn;
	uint32 bam_p_irq_enn;
	uint32 bam_p_timern;
	uint32 bam_p_timer_ctrln;
	uint32 bam_p_prdcr_sdbndn;
	uint32 bam_p_cnsmr_sdbndn;
	uint32 bam_p_evnt_dest_addrn;
	uint32 bam_p_evnt_regn;
	uint32 bam_p_sw_ofstsn;
	uint32 bam_p_data_fifo_addrn;
	uint32 bam_p_desc_fifo_addrn;
	uint32 bam_p_evnt_gen_trshldn;
	uint32 bam_p_fifo_sizesn;
	uint32 bam_p_retr_cntxtn;
	uint32 bam_p_si_cntxtn;
	uint32 bam_p_df_cntxtn;
	uint32 bam_p_au_psm_cntxt_1n;
	uint32 bam_p_psm_cntxt_2n;
	uint32 bam_p_psm_cntxt_3n;
	uint32 bam_p_psm_cntxt_4n;
	uint32 bam_p_psm_cntxt_5n;
	uint32 bam_p_desc_fifo;                         /* Removed pointers as only address */
	uint32 bam_p_desc_fifo_size;
	uint32 bam_p_data_fifo;							/* Removed pointers as only addresss*/
	uint32 bam_p_data_fifo_size;
	/*struct bamdebug_p_register *bam_p_peer_ptr;*/ /* Removed as we are copying from dmesg, we don't have any pointer */
};



/* Don't know where to use ? */
typedef struct
{
	uint32 pipenum;

	uint32 peerpipenum;
	uint32 peerbase_va;
	uint32 peerbase_pa;
	uint32 desc_base_va;
	uint32 *desc_fifo;
	uint32 desc_fifo_size;
	uint32 data_base_va;
	uint32 *data_fifo;
	uint32 data_fifo_size;
}bamdebug_pipe_config;


struct testbus_info
{
	uint32 sel;
	uint32 reg;
};


struct iovec
{
	uint32 desc_addr;
	uint32 desc_data_addr;
	uint32 desc_flags;
};


/* Descirptor Information
   1. Valid descriptor data ?
   2. For which pipe ?
   3. Desc fifo addr
   4. Desc fifo size
   5. Descriptor data
   		1. descriptor address
   		2. descriptor data address / dma_address
   		3. descriptor flags & size
*/
struct desc_info
{
	uint32 valid_info;
	uint32 pipe_num;
	uint32 desc_fifo_addr;
	uint32 desc_fifo_size;
	struct iovec desc_iovec[MAX_DESC_NUM];  /*Supported for 256 descriptor only now*/
};
