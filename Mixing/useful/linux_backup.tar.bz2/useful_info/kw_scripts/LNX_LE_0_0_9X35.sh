#!/bin/bash
echo "rm -rf .kw*"
rm -rf .kw*
echo "kwauth --url https://kwdbprod08.qualcomm.com:8070"
kwauth --url https://kwdbprod08.qualcomm.com:8070
echo "kwcheck create --url https://kwdbprod08:8070/CRM_LNX_LE_0_0_9X35"
kwcheck create --url https://kwdbprod08:8070/CRM_LNX_LE_0_0_9X35
echo "kwcheck import /prj/qct/asw/StaticAnalysis/public/CRM_LNX_LE_0_0_9X35/CRM_LNX_LE_0_0_9X35.tpl"
kwcheck import /prj/qct/asw/StaticAnalysis/public/CRM_LNX_LE_0_0_9X35/CRM_LNX_LE_0_0_9X35.tpl
echo "kwcheck set-var PROJECTROOT=$(pwd)"
kwcheck set-var PROJECTROOT=$(pwd)
echo "kwcheck set-var MYROOT=$(pwd)"
kwcheck set-var MYROOT=$(pwd)
