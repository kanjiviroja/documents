#!/bin/bash
echo "rm -rf .kw*"
rm -rf .kw*
echo "kwauth --url https://kwdbprod08.qualcomm.com:8070"
kwauth --url https://kwdbprod08.qualcomm.com:8070
echo "kwcheck create --url https://kwdbprod08:8070/CI_APSS_LA_2_5"
kwcheck create --url https://kwdbprod08:8070/CI_APSS_LA_2_5
echo "kwcheck import /prj/qct/asw/StaticAnalysis/public/CI_APSS_LA_2_5/CI_APSS_LA_2_5.tpl"
kwcheck import /prj/qct/asw/StaticAnalysis/public/CI_APSS_LA_2_5/CI_APSS_LA_2_5.tpl
echo "kwcheck set-var PROJECTROOT=$(pwd)"
kwcheck set-var PROJECTROOT=$(pwd)
echo "kwcheck set-var MYROOT=$(pwd)"
kwcheck set-var MYROOT=$(pwd)
