#!/bin/bash
echo "rm -rf .kw*"
rm -rf .kw*
echo "kwauth --url https://kwdbprod07.qualcomm.com:8070"
kwauth --url https://kwdbprod07.qualcomm.com:8070
echo "kwcheck create --url https://kwdbprod07:8070/CI_LNX_LA_0_0"
kwcheck create --url https://kwdbprod07:8070/CI_LNX_LA_0_0
echo "kwcheck import /prj/qct/asw/StaticAnalysis/public/CI_LNX_LA_0_0/CI_LNX_LA_0_0.tpl"
kwcheck import /prj/qct/asw/StaticAnalysis/public/CI_LNX_LA_0_0/CI_LNX_LA_0_0.tpl
echo "kwcheck set-var PROJECTROOT=$(pwd)"
kwcheck set-var PROJECTROOT=$(pwd)
echo "kwcheck set-var MYROOT=$(pwd)"
kwcheck set-var MYROOT=$(pwd)
