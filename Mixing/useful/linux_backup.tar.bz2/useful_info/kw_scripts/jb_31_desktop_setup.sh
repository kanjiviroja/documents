#!/bin/bash
echo "rm -rf .kw*"
rm -rf .kw*
echo "kwauth --url https://kwdbprod07.qualcomm.com:8070"
kwauth --url https://kwdbprod07.qualcomm.com:8070
echo "kwcheck create --url https://kwdbprod07:8070/CRM_APSS_LA_3_1_M8974AAAAANLYA"
kwcheck create --url https://kwdbprod07:8070/CRM_APSS_LA_3_1_M8974AAAAANLYA
echo "kwcheck import /prj/qct/asw/StaticAnalysis/public/CRM_APSS_LA_3_1_M8974AAAAANLYA/CRM_APSS_LA_3_1_M8974AAAAANLYA.tpl"
kwcheck import /prj/qct/asw/StaticAnalysis/public/CRM_APSS_LA_3_1_M8974AAAAANLYA/CRM_APSS_LA_3_1_M8974AAAAANLYA.tpl
echo "kwcheck set-var PROJECTROOT=$(pwd)"
kwcheck set-var PROJECTROOT=$(pwd)
echo "kwcheck set-var MYROOT=$(pwd)"
kwcheck set-var MYROOT=$(pwd)
