#!/usr/bin/perl

use strict;
use Win32::OLE qw(in with);
use Win32::OLE::Const 'Microsoft Excel';
use Spreadsheet::WriteExcel;
#use Spreadsheet::WriteExcel::Worksheet;
use Parse::RecDescent;
use Fcntl;
#use WWW::Shorten::TinyURL;

my $fname = $ARGV[0];
my $prjname = $ARGV[2];
my $repname = $ARGV[3];
my $srvrname = "";

if ($prjname eq "CI_APSS_LA_2_3") {
	$srvrname = "kwdbprod03";
} else {
	$srvrname = "kwdbprod05";
}
#}elsif (($prjname eq "CI_APSS_LA_2_5") || ($prjname eq "CI_ANDROID_APSS_LA_0_0")) {
#$srvrname = "kwdbprod05";
#} else {
#	die "Invalid project name";
#}

#creating the report xls 
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
my $filename = "report_"."$repname"."_".($mon+1)."_".$mday.".xls";
my $Book  = Spreadsheet::WriteExcel->new("$filename")
 or die "Could not create a new Excel file $filename: $!";

my $MainSheet = $Book->addworksheet("Main");
my $DetailedSheet = $Book->addworksheet("Detailed");
my $LinksSheet = $Book->addworksheet("Links");
my $mainRow = 0;
my $mainCol = 0;
my $detailedRow = 0;
my $detailedCol = 0;
my $linksRow = 0;
my $linksCol = 0;

open FILE, $fname or die $!;
my @lines = <FILE>;
close(FILE);

my $hash = "%252F";
my $semicolon = "%253A";
my $colon = "%252C";

my $g_match = "";
my $g_techname = "";
my @dname;
my @pathlist;
my %result=("Critical",0,"Major",0,"Minor",0,"Unused",0,"Moderate",0,"UCONF",0,"DeprecatedFunctions",0);
my %totals=("Critical",0,"Major",0,"DeprecatedFunctions",0);
my %subtotals=("Critical",0,"Major",0,"DeprecatedFunctions",0);

#file:/vendor/qcom/,/kernel/,/external/,/bootable/,/system/bluetooth/,/external/bluetooth/,/packages/apps/bluetooth/,/frameworks/base/core/java/android/bluetooth/,/packages/apps/Settings/src/com/android/settings/bluetooth

#my $htlink = "http://kwdbprod02.na.qualcomm.com:8070/klocwork/insight-review.html#issuelist_goto:offset=0,project=CI_ANDROID_GINGERBREAD_MSM8960_SURF,scope=1,searchquery=file%253A%252Fkernel%252F%252C%252Fvendor%252Fqcom%252Fproprietary%252F,sortcolumn=id,sortdirection=ASC,start=0,statestatusid=121";
#my $htlink = "http://kwdbprod02.na.qualcomm.com:8070/klocwork/insight-review.html#issuelist_goto:offset=0,project=CI_ANDROID_GINGERBREAD_MSM8960_SURF_NEW,scope=1,searchquery=file%253A%252Fkernel%252F%252C%252Fvendor%252Fqcom%252Fproprietary%252F+-file%253A%252Ftest%252C-test+severity%253Acritical%252Cmajor,sortcolumn=id,sortdirection=ASC,start=0,statestatusid=119";
#my $htlink = "http://kwdbprod02.na.qualcomm.com:8070/klocwork/insight-review.html#issuelist_goto:offset=0,project=CI_ANDROID_GINGERBREAD_MSM8960_SURF_NEW,scope=1,searchquery=,sortcolumn=id,sortdirection=ASC,start=0,statestatusid=119";
#my $htlink = "http://kwdbprod05.na.qualcomm.com:8070/klocwork/insight-review.html#issuelist_goto:offset=0,project=CI_ANDROID_APSS_LA_0_0,scope=1,searchquery=file%253A%252Fvendor%252Fqcom%252Fproprietary+-severity%253ACritical%252CMajor,sortcolumn=id,sortdirection=ASC,start=0,statestatusid=2";
my  $htlink = "https://$srvrname.na.qualcomm.com:8070/klocwork/insight-review.html#issuelist_goto:offset=0,project=$prjname,scope=1,searchquery=file%253A%252FB%252Fvendor%252Fqcom%252Fproprietary,sortcolumn=id,sortdirection=ASC,start=0,statestatusid=2";

my $allTech;

parseScope();
my @tech = split(";",$allTech); 
parsetecharea();

MainReport();
DetailedReport();

sub parseScope() {
my $fname = $ARGV[1];
open FILE, $fname or die $!;
my @Scopelines = <FILE>;
close(FILE);


my $techAreaEnd = 0;
my @allTechArray;
my $line; 
my @tempTechArea;
my $x = 0;
foreach $line (@Scopelines) {
	chomp($line);
	if($line ne "</COMPONENT>") {
		push(@tempTechArea, $line);
	}else {
		while ( $tempTechArea[0] !~ "<COMPONENT") {
			shift(@tempTechArea);
		}
		$allTech = $allTech.$tempTechArea[0]."\n";
		shift(@tempTechArea);
		foreach my $techLine (@tempTechArea) {
			if ( $techLine =~ /^-/) {
				$techLine = reverse($techLine);
				chop($techLine);
				$techLine = reverse($techLine);
				
				$techLine = "-/".$techLine."\n";
				$allTech = $allTech.$techLine;
			} 
			
		}
		foreach my $techLine (@tempTechArea) {
			if ( $techLine !~ /^-/ and $techLine !~ /^</) {
				$techLine = "/".$techLine."\n";
				$allTech = $allTech.$techLine;
			}
		}
		$allTech = $allTech.";\n";
		@tempTechArea = "";
	}
}
}

sub parsetecharea() {
	#dirpath is a directory
	#arealist contains all the directories from a single functional area
	#line is a line in the issues list
	foreach my $line (@lines) {
		chomp;
		foreach my $arealist (@tech) {
			chomp($arealist);
			my @dirlist = split(" ",$arealist);
			if ( $dirlist[0] == " " ) {
				shift(@dirlist);
			}
			my $techarea = shift(@dirlist);
			foreach my $dirpath (@dirlist) {
				if ($dirpath =~ /^-/) {
					$dirpath = substr($dirpath, 1);
					if ($line =~ /$dirpath/i) {
						$line = "";
						last;
					}
				}

				if ($line =~ /$dirpath/i) {
					if (($line !~ /\/test/i) && ($line !~ /-test/i) && ($line !~ /\/tests/i)) 
					{
						push(@pathlist, "$techarea:$line");
						#print "$techarea:$line" ;
					}
					$line = "";
					last;
				}
				if ($line eq "") {
					last;
				}
			}
		}
	}

	@pathlist = sort(@pathlist);
}

sub htmllink {
   my $techarea;
   my $link = $htlink;
   my $path = @_[0];
   my $str;
   my $srchfile = "searchquery=file%253A";
   my $srchnofile = "+-file%253A";
   my $exltestandlow = "+-file%253A%252Ftest%252C-test+severity%253Acritical%252Cmajor";
   my $arealist;
   my @techarea;
   my @dirlist;
   my $dirpath;
   my @spath;
   foreach $arealist (@tech) {
      chomp($arealist);
      @dirlist = split(" ",$arealist);
	  my $techarea = $dirlist[1];
	  shift(@dirlist);
	  shift(@dirlist);
	  if ($techarea eq $path) {
         foreach $dirpath (@dirlist) {
            @spath = split('/',$dirpath); 
            foreach $path (@spath) {
               if (($path ne "") && ($dirpath !~ /^-/)) {
                  $srchfile = $srchfile . $hash;
				  $srchfile = $srchfile . $path;                  
               }
	           else {
			      if (($path ne "") && ($path ne "-")) {
                     $srchnofile = $srchnofile . $hash;
					 $srchnofile = $srchnofile . $path;
                  }
               }
            }
			if ($dirpath =~ /^-/) {
				$srchnofile = $srchnofile . $colon;
			} else {		   
			   $srchfile = $srchfile . $colon;
			}			
         }
      }
   }
   
   my @shtml = split(',',$htlink);
   $srchfile =~ s/$colon$//;
   
   if ($srchnofile ne "+-file%253A") {
      $srchnofile =~ s/$colon$//;   
      $shtml[3] = $srchfile . $srchnofile . $exltestandlow;
   }  else {
      $shtml[3] = $srchfile . $exltestandlow;
   }
   
   $link = join(',', @shtml);
   chomp($link);
   return $link;
}

sub printToReport {
	if(@_[0] eq "Main") {
		$MainSheet->write($mainRow, $mainCol++, $g_match);
		$MainSheet->write($mainRow, $mainCol++, $result{"Critical"});
		$MainSheet->write($mainRow, $mainCol++, $result{"Major"});
		$MainSheet->write($mainRow, $mainCol++, $result{"DeprecatedFunctions"});
		#$MainSheet->write($mainRow, $mainCol++, $result{"Minor"});
		#$MainSheet->write($mainRow, $mainCol++, $result{"Unused"});
		#$MainSheet->write($mainRow, $mainCol++, $result{"Moderate"});
		#$MainSheet->write($mainRow, $mainCol++, $result{"UCONF"});
		$mainRow++;
		$mainCol = 0;

		$subtotals{"Critical"}+=$result{"Critical"};
		$subtotals{"Major"}+=$result{"Major"};
		$subtotals{"DeprecatedFunctions"}+=$result{"DeprecatedFunctions"};
		
		$totals{"Critical"}+=$result{"Critical"};
		$totals{"Major"}+=$result{"Major"};
		$totals{"DeprecatedFunctions"}+=$result{"DeprecatedFunctions"};
		
	} elsif ( @_[0] eq "Detailed" ) {
		$DetailedSheet->write($detailedRow, $detailedCol++, $g_match);
		$DetailedSheet->write($detailedRow, $detailedCol++, $result{"Critical"});
		$DetailedSheet->write($detailedRow, $detailedCol++, $result{"Major"});
		$DetailedSheet->write($detailedRow, $detailedCol++, $result{"DeprecatedFunctions"});
		#$DetailedSheet->write($detailedRow, $detailedCol++, $result{"Minor"});
		#$DetailedSheet->write($detailedRow, $detailedCol++, $result{"Unused"});
		#$DetailedSheet->write($detailedRow, $detailedCol++, $result{"Moderate"});
		#$DetailedSheet->write($detailedRow, $detailedCol++, $result{"UCONF"});
		$detailedRow++;
		$detailedCol = 0;	
	}
}

sub printstats {
	my $line = @_[1];
	my $techname = @_[0];
	my $str;

	if ($line eq "") {
		return;
	}

	# Get semi-colon separated list
	my @pass1 = split(/;/,$line);
	my @spath = split('/',$pass1[0]);

	#Remove /local/mnt/workspace/workspace/src/CI_ANDROID_GINGERBREAD_MSMXXX../
	splice(@spath,0,8);
   
	if (  @_[2] eq "Detailed" ) {
		$str = join('/',@spath);
	} else { 
		#Remove file name
		$fname = pop(@spath);
		splice(@spath,4);
		$str = join('/',@spath);
	}

	if ($g_match eq "") {
		$g_match = $str;
	}
	if ($g_techname eq "") {
		$g_techname = $techname;
	}

	if (!(($g_match eq $str) && ($g_techname eq $techname))) {
		printToReport(@_[2]);
		%result=("Critical",0,"Major",0,"Minor",0,"Unused",0,"Moderate",0,"UCONF",0,"DeprecatedFunctions",0);
		$g_match = $str;
		$g_techname = $techname;
	}
	
	if ($pass1[6] eq "DeprecatedFunctions") {
		$result{$pass1[6]} ++;
	}
	else {
		$result{$pass1[3]} ++;
	}
}

sub MainReport {
	#print "Directory Critical Major Deprecated";
	$MainSheet->write($mainRow, $mainCol++, "Directory");
	$MainSheet->write($mainRow, $mainCol++, "Critical");
	$MainSheet->write($mainRow, $mainCol++, "Major");
	$MainSheet->write($mainRow, $mainCol++, "Deprecated");
	$mainRow++; $mainCol = 0;

	my $currentTechArea = "";
	my $currentTechRow = 0;
	my $tempCounter = 0;
	#my $format = $MainSheet->add_format();
	#$format->set_bold();
	#print "@pathlist";
	foreach (@pathlist) {
		my $techArea = "";
		my $techPath = "";

		($techArea,$techPath) = split(':',$_);
		printstats($techArea,$techPath,"Main");
		if ( $techArea ne $currentTechArea ) {

			# print the total issues for each tech area
			if( $currentTechRow ne 0 ) { # skipping the first attempt to write since there no tech defined yet
				$MainSheet->write($mainRow, $mainCol, "TOTAL");
				$MainSheet->write($mainRow, ++$mainCol, $subtotals{"Critical"});
				$MainSheet->write($mainRow, ++$mainCol, $subtotals{"Major"});
				$MainSheet->write($mainRow, ++$mainCol, $subtotals{"DeprecatedFunctions"});
				$MainSheet->write($mainRow, ++$mainCol, $subtotals{"Critical"}+$subtotals{"Major"}+$subtotals{"DeprecatedFunctions"});
			}
			
			

			$subtotals{"Critical"} = 0;
			$subtotals{"Major"} = 0;
			$subtotals{"DeprecatedFunctions"} = 0;
		
			$mainCol = 0;

			$mainRow+=3; #leaving a row between two tech areas
			$currentTechRow = $mainRow;

			$MainSheet->write($mainRow, $mainCol, $techArea);
			#$MainSheet->write_url($mainRow, $mainCol,  htmllink($techArea), $techArea);
			$mainRow++;
			$currentTechArea = $techArea;

			if ( $techArea eq "USB" or $techArea eq "QCOM_PROPRIETARY" or $techArea eq "BOOT" or $techArea eq "CAMERA" ) {
				#print htmllink($techArea);
				#print "\n\n";
			}

			$linksRow++;
			$LinksSheet->write($linksRow++,$linksCol, $techArea);
			$LinksSheet->write($linksRow,$linksCol, htmllink($techArea));
			$linksRow++;	
		}

	}
	printToReport("Main");
	$MainSheet->write($mainRow, $mainCol, "TOTAL");
	$MainSheet->write($mainRow, ++$mainCol, $subtotals{"Critical"});
	$MainSheet->write($mainRow, ++$mainCol, $subtotals{"Major"});
	$MainSheet->write($mainRow, ++$mainCol, $subtotals{"DeprecatedFunctions"});
	$MainSheet->write($mainRow, ++$mainCol, $subtotals{"Critical"}+$subtotals{"Major"}+$subtotals{"DeprecatedFunctions"});
	#	$MainSheet->write($currentTechRow, $mainCol+4, $subtotals{"Critical"}+$subtotals{"Major"}+$subtotals{"DeprecatedFunctions"});

	$mainRow+=2;
	$mainCol = 0;
	$MainSheet->write($mainRow, $mainCol++, "Total");
	$MainSheet->write($mainRow, $mainCol++, $totals{"Critical"});
	$MainSheet->write($mainRow, $mainCol++, $totals{"Major"});
	$MainSheet->write($mainRow, $mainCol++, $totals{"DeprecatedFunctions"});
	$MainSheet->write($mainRow, $mainCol++, $totals{"Critical"} + $totals{"Major"} + $totals{"DeprecatedFunctions"});
}

sub DetailedReport {
	#print "Directory Critical Major Deprecated";
	$DetailedSheet->write($detailedRow, $detailedCol++, "Directory");
	$DetailedSheet->write($detailedRow, $detailedCol++, "Critical");
	$DetailedSheet->write($detailedRow, $detailedCol++, "Major");
	$DetailedSheet->write($detailedRow, $detailedCol++, "Deprecated");
	$detailedRow++; $detailedCol = 0;

	my $currentTechArea = "";

	foreach (@pathlist) {
	   my $techArea = "";
	   my $techPath = "";
	   ($techArea,$techPath) = split(':',$_);
	   printstats($techArea,$techPath,"Detailed");
	   if ( $techArea ne $currentTechArea ) {
		$detailedRow++; #leaving a row between two tech areas
		#$DetailedSheet->write_url($detailedRow, $detailedCol, htmllink($techArea), $techArea);
		$DetailedSheet->write($detailedRow, $detailedCol, $techArea);
		$detailedRow++;
		$currentTechArea = $techArea;
	   }
	   
	}
	printToReport("Detailed");
}
